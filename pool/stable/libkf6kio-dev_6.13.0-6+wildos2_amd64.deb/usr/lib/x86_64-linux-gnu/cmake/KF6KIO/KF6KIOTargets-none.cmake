#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::KIOCore" for configuration "None"
set_property(TARGET KF6::KIOCore APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::KIOCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Xml;Qt6::Concurrent;KF6::ConfigCore;KF6::I18n;KF6::Service;KF6::Crash;KF6::AuthCore"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOCore.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6KIOCore.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::KIOCore )
list(APPEND _cmake_import_check_files_for_KF6::KIOCore "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOCore.so.6.13.0" )

# Import target "KF6::KIOGui" for configuration "None"
set_property(TARGET KF6::KIOGui APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::KIOGui PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::Solid;KF6::I18n;KF6::WindowSystem"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOGui.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6KIOGui.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::KIOGui )
list(APPEND _cmake_import_check_files_for_KF6::KIOGui "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOGui.so.6.13.0" )

# Import target "KF6::KIOWidgets" for configuration "None"
set_property(TARGET KF6::KIOWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::KIOWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Concurrent;KF6::I18n;KF6::ConfigGui;KF6::GuiAddons;KF6::IconThemes;KF6::IconWidgets;KF6::WindowSystem;KF6::ColorScheme;Qt6::DBus"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOWidgets.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6KIOWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::KIOWidgets )
list(APPEND _cmake_import_check_files_for_KF6::KIOWidgets "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOWidgets.so.6.13.0" )

# Import target "KF6::KIOFileWidgets" for configuration "None"
set_property(TARGET KF6::KIOFileWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::KIOFileWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::GuiAddons;KF6::IconThemes;KF6::IconWidgets;KF6::I18n;KF6::ConfigGui;KF6::BookmarksWidgets;KF6::ColorScheme"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOFileWidgets.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6KIOFileWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::KIOFileWidgets )
list(APPEND _cmake_import_check_files_for_KF6::KIOFileWidgets "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libKF6KIOFileWidgets.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
