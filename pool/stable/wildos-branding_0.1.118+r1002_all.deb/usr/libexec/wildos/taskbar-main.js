// Keeps the taskbar on the main display, as Windows does. Plasma numbers
// the main display 0 and moves whatever is on 0 when the main display
// changes, so a taskbar that was made on another screen (number 1, say)
// stayed on whichever screen was not the main one. Moving it to 0 once puts
// it right, and it follows the main display from then on. A taskbar is a
// bar with the clock; the top bar and any bar already on the main display
// are left alone. taskbar-items runs this at every sign-in.
var bars = panels().filter(function (p) { return p.widgets("org.wildos.clock").length > 0; });
var onMain = bars.some(function (p) { return p.screen === 0; });
if (!onMain && bars.length > 0) {
    var bar = bars[0];
    var locked = bar.locked;
    bar.locked = false;
    bar.screen = 0;
    bar.locked = locked;
}
