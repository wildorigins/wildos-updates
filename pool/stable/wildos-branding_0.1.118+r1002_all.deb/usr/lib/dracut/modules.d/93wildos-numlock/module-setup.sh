#!/bin/bash
# Num Lock at the disk unlock prompt, which runs in the initramfs, so a
# numeric disk password can be typed on the number pad straight away. Only
# when Settings > Keyboard's "Num Lock when you sign in" is On: Settings
# keeps that in GRUB's environment, and the start-up menu passes it on as
# wildos.numlock=1. Never on by default, since on a laptop whose number pad
# shares the letter keys Num Lock would turn letters into digits.

check() {
    require_binaries setleds || return 1
    return 0
}

depends() {
    return 0
}

install() {
    inst_multiple setleds
    inst_hook cmdline 50 "$moddir/wildos-numlock.sh"
}
