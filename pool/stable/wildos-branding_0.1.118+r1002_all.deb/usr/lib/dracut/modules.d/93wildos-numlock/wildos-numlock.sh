#!/bin/sh
# The unlock prompt reads the keyboard through the consoles, so Num Lock is
# set on each of them before it appears.
if getargbool 0 wildos.numlock; then
    for tty in /dev/tty1 /dev/tty2 /dev/tty3 /dev/tty4 /dev/tty5 /dev/tty6; do
        [ -c "$tty" ] && setleds -D +num < "$tty" > /dev/null 2>&1
    done
fi
