import QtQuick

// A reading's last minute, one value a second, oldest first, kept only while
// the bar is live so the graph is already full when its panel opens. The
// tick is the bar's own; nothing runs while it is hidden.
Timer {
    id: history

    property bool live: false
    // Returns the value to keep for this second, or NaN to keep nothing.
    property var sample: () => NaN
    property int span: 60
    property var values: []

    signal ticked()

    interval: 1000
    repeat: true
    running: live
    triggeredOnStart: true

    onTriggered: {
        const v = sample();
        if (!isNaN(v)) {
            const next = values.length >= span ? values.slice(values.length - span + 1) : values.slice();
            next.push(v);
            values = next;
        }
        ticked();
    }
}
