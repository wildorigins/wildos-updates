import QtQuick

// Which readings this PC can offer, kept up to date: Battery only with a
// built-in battery, Cooler only while a supported cooler is connected. Both
// are told about changes (UPower, the cooler service's name on the system
// bus) rather than asking on a timer. Settings previews can turn it off.
QtObject {
    id: availability

    property bool enabled: true

    readonly property bool battery: batteryLoader.item !== null && batteryLoader.item.hasBattery
    readonly property bool cooler: coolerLoader.item !== null && coolerLoader.item.present

    property list<QtObject> resources: [
        Loader {
            id: batteryLoader
            active: availability.enabled
            source: "readings/BatterySource.qml"
        },
        Loader {
            id: coolerLoader
            active: availability.enabled
            source: "readings/CoolerProbe.qml"
        }
    ]
}
