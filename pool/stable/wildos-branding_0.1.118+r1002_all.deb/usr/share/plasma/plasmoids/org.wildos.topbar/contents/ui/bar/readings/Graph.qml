pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Shapes

// Board 4.16's minute graph: 288 by 84, radius 8 on rgba(255,255,255,0.04),
// grid lines at a quarter, half and three quarters, the area in the accent
// at 0.16 under a 1.8px line. One point a second, newest at the right edge;
// a history shorter than a minute fills from the right, as Task Manager's do.
Item {
    id: graph

    property var values: []
    property real minimum: 0
    property real maximum: 100
    property color color: "#8fb4ff"
    property int span: 60

    implicitWidth: 288
    implicitHeight: 84

    readonly property real step: width / (span - 1)
    readonly property var points: {
        const list = values || [];
        const count = Math.min(list.length, span);
        const range = Math.max(0.0001, maximum - minimum);
        const out = [];
        for (let i = 0; i < count; ++i) {
            const v = list[list.length - count + i];
            const share = Math.max(0, Math.min(1, (v - minimum) / range));
            // Kept a pixel inside so the line is never cut by the edge.
            out.push(Qt.point(width - (count - 1 - i) * step, Math.max(1, Math.min(height - 1, height - share * height))));
        }
        return out;
    }

    Rectangle {
        anchors.fill: parent
        radius: 8
        color: Qt.rgba(1, 1, 1, 0.04)
    }

    Repeater {
        model: 3
        Rectangle {
            required property int index
            x: 0
            y: Math.round(graph.height * (index + 1) / 4) - 0.5
            width: graph.width
            height: 1
            color: Qt.rgba(1, 1, 1, 0.07)
        }
    }

    Shape {
        anchors.fill: parent
        visible: graph.points.length > 1
        preferredRendererType: Shape.CurveRenderer

        // The area follows the line, then the rounded bottom corners of the
        // background, so it never pokes out of them.
        ShapePath {
            strokeColor: "transparent"
            fillColor: Qt.rgba(graph.color.r, graph.color.g, graph.color.b, 0.16)
            PathSvg {
                path: {
                    const p = graph.points;
                    if (p.length < 2) {
                        return "";
                    }
                    const h = graph.height;
                    const w = graph.width;
                    let d = "M" + p[0].x + " " + p[0].y;
                    for (let i = 1; i < p.length; ++i) {
                        d += "L" + p[i].x + " " + p[i].y;
                    }
                    d += "L" + w + " " + Math.max(p[p.length - 1].y, h - 8) + "A8 8 0 0 1 " + (w - 8) + " " + h;
                    d += p[0].x < 8 ? "L8 " + h + "A8 8 0 0 1 0 " + (h - 8) : "L" + p[0].x + " " + h;
                    return d + "Z";
                }
            }
        }

        ShapePath {
            strokeColor: graph.color
            strokeWidth: 1.8
            fillColor: "transparent"
            joinStyle: ShapePath.RoundJoin
            capStyle: ShapePath.RoundCap
            PathPolyline {
                path: graph.points
            }
        }
    }
}
