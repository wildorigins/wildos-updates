import QtQuick
import org.kde.plasma.workspace.dbus as DBus
import org.kde.ksysguard.sensors as Sensors

// The cooler's liquid temperature, pump and fans from wildos-cooler's
// service (it reads the cooler once a second), and the graphics card's
// temperature from ksystemstats for the second reading on board 4.20. Asked
// once a second only while the bar is live and a cooler is there.
Item {
    id: source

    property bool live: false

    readonly property bool present: probe.present
    readonly property bool fansOnCooler: probe.fansOnCooler
    readonly property string model: probe.model
    property real liquid: NaN
    property int pumpRpm: 0
    property int pumpDuty: 0
    property int fanRpm: 0
    property int fanDuty: 0
    readonly property real gpuTemperature: gpuTemp.status === Sensors.Sensor.Ready && Number(gpuTemp.value) > 0 ? Number(gpuTemp.value) : NaN
    readonly property alias values: history.values

    property bool asking: false

    function read(): void {
        if (asking) {
            return;
        }
        asking = true;
        const reply = DBus.SystemBus.asyncCall({
            service: "io.wildos.Cooler",
            path: "/io/wildos/Cooler",
            iface: "io.wildos.Cooler1",
            member: "Readings"
        });
        reply.finished.connect(() => {
            source.asking = false;
            if (reply.isError) {
                return;
            }
            const got = probe.unwrap(reply.value) || {};
            const n = key => Number(probe.unwrap(got[key]));
            if (got.liquid === undefined) {
                return;
            }
            source.liquid = n("liquid");
            source.pumpRpm = n("pumpRpm") || 0;
            source.pumpDuty = n("pumpDuty") || 0;
            source.fanRpm = n("fanRpm") || 0;
            source.fanDuty = n("fanDuty") || 0;
        });
    }

    CoolerProbe {
        id: probe
    }

    Sensors.Sensor {
        id: gpuTemp
        sensorId: "gpu/gpu0/temperature"
        enabled: source.live && probe.present
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live && probe.present
        sample: () => source.liquid
        onTicked: source.read()
    }
}
