import QtQuick
import WildOS.UI as UI
import org.wildos.shell as WildOS
import ".."
import "../Defaults.js" as Defaults

// A pinned folder or file: the board's folder in #f3c969, or the file's
// own type icon, and its name. It opens in Files or the file's app.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property string path: config && config.path ? String(config.path) : ""
    property var info: WildOS.TopBarSettings.pathInfo(path)

    readonly property bool shown: path.length > 0
    readonly property string accessibleName: info.folder ? qsTr("%1 folder").arg(info.name) : info.name

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    onPathChanged: info = WildOS.TopBarSettings.pathInfo(path)

    function activate(): void {
        if (preview || !host) {
            return;
        }
        // It may have been made, moved back or deleted since the bar read it.
        info = WildOS.TopBarSettings.pathInfo(path);
        if (info.exists) {
            host.openPath(info.url);
        }
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        opacity: item.info.exists || item.preview ? 1 : 0.55
        tip: item.info.exists || item.preview ? item.path : qsTr("%1 is not there any more").arg(item.path)
        onClicked: item.activate()

        UI.Glyph {
            anchors.verticalCenter: parent.verticalCenter
            visible: item.info.folder || !item.info.exists
            width: 14
            height: 14
            path: item.info.folder || !item.info.exists ? Defaults.icons.folder : Defaults.icons.file
            color: "#f3c969"
        }

        UI.ThemeIcon {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.info.folder && item.info.exists
            width: 16
            height: 16
            name: item.info.icon
            fallback: "text-x-generic"
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical
            text: item.info.name
            size: button.textSize
            color: button.ink
            width: Math.min(implicitWidth, 160)
        }
    }
}
