import QtQuick
import org.kde.ksysguard.sensors as Sensors
import org.wildos.shell as WildOS

// The first graphics card's use, temperature and core speed. An NVIDIA card
// on NVIDIA's driver is read through the driver's own library
// (WildOS.NvidiaGpu): ksystemstats only reads one by running nvidia-smi,
// which NVIDIA's repository leaves out. Any other card comes from
// ksystemstats, the sensors Task Manager reads. A card nothing reports for
// leaves ksystemstats' sensor loading for ever, so three seconds live
// without a value is `missing`.
Item {
    id: source

    property bool live: false
    // Count which app uses the card most, for the reading panel.
    property bool watchApps: false

    // Until the library has answered, ksystemstats is left alone: on an
    // NVIDIA PC it would start nvidia-smi only to be stopped again.
    readonly property bool nvidia: nv.available
    readonly property bool sensorsWanted: live && nv.checked && !nv.available

    readonly property bool ready: nvidia || usage.status === Sensors.Sensor.Ready
    property int waited: 0
    readonly property bool missing: !ready && waited >= 3
    readonly property real percent: nvidia ? nv.percent : ready ? Number(usage.value) || 0 : 0
    readonly property real temperature: nvidia ? nv.temperature
        : temp.status === Sensors.Sensor.Ready && Number(temp.value) > 0 ? Number(temp.value) : NaN
    readonly property real speed: nvidia ? nv.speed
        : frequency.status === Sensors.Sensor.Ready ? Number(frequency.value) || 0 : 0
    readonly property alias values: history.values

    // The panel's "Using the most" row, when the driver's library counts it.
    readonly property alias apps: nv

    WildOS.NvidiaGpu {
        id: nv
        live: source.live
        watchApps: source.watchApps
    }

    Sensors.Sensor {
        id: usage
        sensorId: "gpu/gpu0/usage"
        enabled: source.sensorsWanted
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: temp
        sensorId: "gpu/gpu0/temperature"
        enabled: source.sensorsWanted
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: frequency
        sensorId: "gpu/gpu0/coreFrequency"
        enabled: source.sensorsWanted
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.percent : NaN
        onTicked: {
            if (!source.ready && source.waited < 3) {
                source.waited++;
            }
        }
    }
}
