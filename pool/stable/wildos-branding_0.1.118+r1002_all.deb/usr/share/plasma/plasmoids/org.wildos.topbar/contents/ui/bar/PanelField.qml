import QtQuick
import WildOS.UI as UI
import "Defaults.js" as Defaults

// The search field in the Add panel and its steps (board 4.17): 34px,
// radius 8, rgba(255,255,255,0.06) with a 0.10 edge, the magnifier at 14px
// and 13px text, the placeholder at 0.42.
Rectangle {
    id: field

    property alias text: input.text
    property string placeholder

    signal accepted()
    signal upPressed()
    signal downPressed()
    signal escapePressed()

    function focusField(): void {
        input.forceActiveFocus();
    }

    implicitHeight: 34
    radius: 8
    color: Qt.rgba(1, 1, 1, 0.06)
    border.width: 1
    border.color: input.activeFocus ? Qt.rgba(1, 1, 1, 0.18) : Qt.rgba(1, 1, 1, 0.10)

    UI.Glyph {
        id: glass
        x: 11
        anchors.verticalCenter: parent.verticalCenter
        width: 14
        height: 14
        path: Defaults.icons.search
        color: Qt.rgba(1, 1, 1, 0.42)
    }

    TextInput {
        id: input
        anchors.left: glass.right
        anchors.leftMargin: 9
        anchors.right: parent.right
        anchors.rightMargin: 11
        anchors.verticalCenter: parent.verticalCenter
        color: "#ffffff"
        selectionColor: Qt.rgba(1, 1, 1, 0.25)
        font.family: UI.Style.fontFamily
        font.pixelSize: UI.Style.px(13)
        clip: true
        selectByMouse: true
        Accessible.name: field.placeholder
        Keys.onReturnPressed: field.accepted()
        Keys.onEnterPressed: field.accepted()
        Keys.onUpPressed: field.upPressed()
        Keys.onDownPressed: field.downPressed()
        Keys.onEscapePressed: field.escapePressed()

        UI.Label {
            anchors.fill: parent
            visible: input.text.length === 0
            text: field.placeholder
            size: 13
            color: Qt.rgba(1, 1, 1, 0.42)
        }
    }
}
