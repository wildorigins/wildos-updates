import QtQuick
import org.kde.plasma.plasma5support as P5Support
import org.kde.plasma.private.weather as Weather

// Finds weather places by name for the top bar through Plasma's weather
// engine, the same providers and search as Plasma's Weather widget. Nothing
// about where the PC is leaves it: the only hint is the city of the system
// time zone ("Europe/London" gives London), read on this PC, which the
// search starts with.
Item {
    id: locator

    // [{ name, source }] from the last search.
    property var results: []
    property bool searching: false
    property string searchedFor: ""

    // The time engine names the zone's city in the user's language.
    readonly property string timeZoneCity: {
        const local = timeEngine.data["Local"];
        const city = local ? String(local["Timezone City"] || "") : "";
        return city === "UTC" ? "" : city.replace(/_/g, " ");
    }

    readonly property string timeZone: {
        const local = timeEngine.data["Local"];
        return local ? String(local["Timezone"] || "") : "";
    }

    // The providers that cover this PC's part of the world, best first: by
    // the regional format's country, else by the time zone's continent.
    readonly property string country: (Qt.locale().name.split("_")[1] || "").toUpperCase()
    readonly property var nearProviders: {
        const byCountry = { GB: ["bbcukmet"], IE: ["bbcukmet"], DE: ["dwd"], AT: ["dwd"], CH: ["dwd"],
                            CA: ["envcan"], US: ["noaa"] };
        if (byCountry[country]) {
            return byCountry[country];
        }
        const continent = timeZone.split("/")[0];
        return continent === "Europe" ? ["bbcukmet", "dwd"] : continent === "America" ? ["noaa", "envcan"] : [];
    }

    // Plasma lists results provider by provider. The place named exactly
    // as searched, from a provider for this part of the world, goes first,
    // so the time zone's city is usually one click away.
    function rank(place: var, query: string): real {
        const parts = String(place.source).split("|");
        const words = String(parts[2] || "").split(",").map(w => w.trim());
        let score = words[0].toLowerCase() === query.toLowerCase() ? 2 : 0;
        if (country.length > 0 && words.length > 1 && words[words.length - 1] === country) {
            score += 1.5;
        }
        if (nearProviders.indexOf(parts[0]) >= 0) {
            score += 1 + (nearProviders.length - nearProviders.indexOf(parts[0])) / 10;
        }
        return score;
    }

    readonly property var fallbackProviders: ["bbcukmet", "dwd", "envcan", "noaa", "wettercom"]
    readonly property var providers: {
        // { "plasma_engine_bbcukmet": "BBC Weather|bbcukmet", ... }
        const ions = ionsEngine.data["ions"];
        const ids = ions ? Object.keys(ions).map(key => String(ions[key]).split("|")[1]).filter(id => !!id) : [];
        return ids.length > 0 ? ids : fallbackProviders;
    }

    function search(text: string): void {
        const query = text.trim();
        searchedFor = query;
        if (query.length === 0) {
            searching = false;
            results = [];
            places.clear();
            return;
        }
        searching = true;
        places.searchLocations(query, providers);
    }

    P5Support.DataSource {
        id: ionsEngine
        engine: "weather"
        connectedSources: ["ions"]
    }

    P5Support.DataSource {
        id: timeEngine
        engine: "time"
        connectedSources: ["Local"]
    }

    Weather.LocationListModel {
        id: places
        onLocationSearchDone: (success, searchString) => {
            if (searchString !== locator.searchedFor) {
                return;
            }
            const list = [];
            for (let i = 0; i < places.rowCount(); ++i) {
                const source = places.valueForListIndex(i);
                if (source) {
                    list.push({ name: places.nameForListIndex(i), source: source });
                }
            }
            const scored = list.map((place, i) => ({ place: place, score: locator.rank(place, searchString), i: i }));
            scored.sort((a, b) => b.score - a.score || a.i - b.i);
            locator.results = scored.map(s => s.place);
            locator.searching = false;
        }
    }
}
