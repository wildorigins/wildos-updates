pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Graphics: the ring and "8%" (TopBar.dc), the board 4.16 panel on a click.
// Which app uses the card most needs the driver's per-app figure; where the
// system has none the row says so instead of guessing. On NVIDIA's driver
// the card's own library counts it, elsewhere libksysguard does.
ReadingItem {
    id: gpu
    taskManagerPage: "performance/gpu"

    readonly property var src: loader.item
    readonly property bool missing: !preview && src !== null && src.missing
    readonly property real percent: preview ? 8 : src ? src.percent : 0

    label: qsTr("Graphics")
    valueText: missing ? "" : Format.percent(percent)
    accessibleName: missing ? qsTr("Graphics, not reported on this PC") : qsTr("%1 %2").arg(label).arg(valueText)
    ring: percent / 100

    Loader {
        id: loader
        active: !gpu.preview
        source: "../readings/GpuSource.qml"
        onLoaded: {
            item.live = Qt.binding(() => gpu.live);
            item.watchApps = Qt.binding(() => gpu.panelOpen);
        }
    }

    readonly property bool nvidia: src !== null && src.nvidia

    Loader {
        id: top
        active: !gpu.preview && gpu.panelOpen && gpu.src !== null && gpu.src.apps.checked && !gpu.nvidia
        source: "../readings/TopApp.qml"
        onLoaded: {
            item.metric = "gpu";
            item.active = true;
        }
    }

    readonly property string topText: nvidia ? nvidiaTop() : top.item ? top.item.text(Format.percent) : qsTr("Checking")

    function nvidiaTop(): string {
        const apps = src.apps;
        if (!apps.appsSupported) {
            return qsTr("Not reported on this PC");
        }
        if (!apps.appsCounted) {
            return qsTr("Checking");
        }
        if (!apps.leader.name) {
            return qsTr("No app is using it");
        }
        // The row elides at its end, which would cut off the share.
        const name = apps.leader.name.length > 22 ? apps.leader.name.slice(0, 21).trim() + "…" : apps.leader.name;
        return qsTr("%1, %2").arg(name).arg(Format.percent(apps.leader.value));
    }

    panel: Component {
        ReadingPanel {
            title: gpu.label
            value: gpu.missing ? qsTr("Not reported") : gpu.valueText
            values: gpu.src ? gpu.src.values : []
            accent: gpu.accent
            graphName: qsTr("Graphics use over the last minute")
            rows: [
                { label: qsTr("Temperature"), value: gpu.src && !isNaN(gpu.src.temperature) ? Format.degrees(gpu.src.temperature) : qsTr("Not reported") },
                { label: qsTr("Using the most"), value: gpu.topText },
                { label: qsTr("Speed"), value: gpu.src && gpu.src.speed > 0 ? Format.gigahertz(gpu.src.speed) : qsTr("Not reported") }
            ]
            onLinkActivated: gpu.openTaskManager()
            Component.onCompleted: gpu.panelOpen = true
            Component.onDestruction: gpu.panelOpen = false
        }
    }
}
