import QtQuick
import WildOS.UI as UI
import org.wildos.shell as WildOS
import ".."
import "../Defaults.js" as Defaults

// Another clock: a city in another time zone and its time (board 4.15,
// "Tokyo 22:10"). Compact and edit mode draw a globe in place of the city
// (boards 4.17 and 4.18); upright, the hours sit over the minutes.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property string zone: config && config.zone ? String(config.zone) : "UTC"
    readonly property string city: config && config.city ? String(config.city) : zone.split("/").pop().replace(/_/g, " ")

    // Bumped each minute while the bar is showing; the time follows it.
    property int tick: 0
    readonly property string time: {
        tick;
        return WildOS.TopBarSettings.timeIn(zone, UI.TimeFormat.shortFormat);
    }
    // Upright, the hours go over the minutes; AM or PM has no room.
    readonly property var parts: time.replace(/[^0-9:.]/g, "").split(/[:.]/)
    readonly property string hours: parts[0] || ""
    readonly property string minutes: parts[1] || ""
    readonly property string longDate: {
        tick;
        return WildOS.TopBarSettings.timeIn(zone, "dddd d MMMM");
    }

    readonly property bool shown: true
    readonly property string accessibleName: qsTr("%1 time %2").arg(city).arg(time)

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    // Windows' clocks lead to the date and time settings, where the
    // clocks for other time zones live too.
    function activate(): void {
        if (!preview && host) {
            host.openSettings("datetime");
        }
    }

    onLiveChanged: {
        if (live) {
            tick++;
        }
    }

    // Wakes on the minute rather than every second.
    Timer {
        running: item.live && !item.preview
        repeat: true
        interval: 60000 - (Date.now() % 60000) + 50
        onTriggered: {
            item.tick++;
            interval = 60000 - (Date.now() % 60000) + 50;
        }
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        tip: qsTr("%1, %2").arg(item.city).arg(item.longDate)
        onClicked: item.activate()

        UI.Glyph {
            anchors.verticalCenter: parent.verticalCenter
            visible: item.compact && !item.vertical
            width: 13
            height: 13
            path: Defaults.icons.clock
            color: Qt.rgba(1, 1, 1, 0.7)
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical
            text: item.city
            size: button.textSize
            color: button.inkMuted
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.vertical
            text: item.time
            size: button.textSize
            color: button.ink
            font.weight: UI.Style.weightSemiBold
            font.features: { "tnum": 1 }
        }

        Column {
            visible: item.vertical
            spacing: -2

            UI.Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: item.hours
                size: 11
                color: button.ink
                font.weight: UI.Style.weightSemiBold
                font.features: { "tnum": 1 }
            }

            UI.Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: item.minutes
                size: 11
                color: button.inkMuted
                font.weight: UI.Style.weightSemiBold
                font.features: { "tnum": 1 }
            }
        }
    }
}
