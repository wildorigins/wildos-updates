pragma ComponentBehavior: Bound

import QtQuick
import WildOS.UI as UI
import ".."
import "../Defaults.js" as Defaults

// The second step of adding Weather, inside the "Add to ..." panel, in its
// language (TopBarEdit.dc: 13px semibold heading, the 34px field, 44px
// rows). A place is searched for by name through Plasma's weather
// providers; the search starts filled in with the city of the system time
// zone, so for most people the right place is the first row. Nothing about
// where the PC is is sent anywhere.
Item {
    id: setup

    signal done(var config)
    signal cancelled()

    readonly property var locator: locatorLoader.item
    property int current: 0

    implicitWidth: 288
    implicitHeight: column.implicitHeight

    function pick(place: var): void {
        // A source is "provider|weather|place, region|id".
        const name = String(place.source).split("|")[2] || place.name;
        done({ type: "weather", source: place.source, place: name.split(",")[0].trim() });
    }

    // Filled in once, when the time zone's city is known, unless someone
    // has started typing.
    property bool prefilled: false
    function prefill(): void {
        const city = locator ? locator.timeZoneCity : "";
        if (prefilled || city.length === 0) {
            return;
        }
        prefilled = true;
        if (field.text.length === 0) {
            field.text = city;
        }
    }
    Connections {
        target: setup.locator
        function onTimeZoneCityChanged() {
            setup.prefill();
        }
    }

    // Plasma names a result "Place, region (Provider)".
    function parts(name: string): var {
        const open = name.lastIndexOf(" (");
        const where = open > 0 ? name.slice(0, open) : name;
        const provider = open > 0 ? name.slice(open + 2, name.length - 1) : "";
        const comma = where.indexOf(",");
        return {
            title: comma > 0 ? where.slice(0, comma).trim() : where,
            subtitle: [comma > 0 ? where.slice(comma + 1).trim() : "", provider].filter(s => s.length > 0).join(", ")
        };
    }

    Loader {
        id: locatorLoader
        source: "../readings/WeatherLocator.qml"
        onLoaded: setup.prefill()
    }

    Column {
        id: column
        width: parent.width
        spacing: 12

        UI.Label {
            width: parent.width
            size: 13
            font.weight: UI.Style.weightSemiBold
            color: "#ffffff"
            text: qsTr("Weather for which place?")
        }

        PanelField {
            id: field
            width: parent.width
            placeholder: qsTr("Find a place")
            Component.onCompleted: focusField()
            onTextChanged: {
                setup.current = 0;
                delay.restart();
            }
            onAccepted: {
                if (setup.locator && setup.locator.results.length > 0) {
                    setup.pick(setup.locator.results[Math.min(setup.current, setup.locator.results.length - 1)]);
                }
            }
            onDownPressed: setup.current = Math.min(list.count - 1, setup.current + 1)
            onUpPressed: setup.current = Math.max(0, setup.current - 1)
            onEscapePressed: setup.cancelled()

            // Each provider is asked over the network; a pause in typing
            // asks once instead of on every letter.
            Timer {
                id: delay
                interval: 500
                onTriggered: {
                    if (setup.locator) {
                        setup.locator.search(field.text);
                    }
                }
            }
        }

        UI.Label {
            width: parent.width
            visible: text.length > 0
            size: 12.5
            wrapMode: Text.WordWrap
            color: Qt.rgba(1, 1, 1, 0.68)
            text: {
                const l = setup.locator;
                if (!l || field.text.trim().length === 0) {
                    return "";
                }
                if (l.searching) {
                    return qsTr("Searching");
                }
                return l.searchedFor === field.text.trim() && l.results.length === 0
                    ? qsTr("No places found. Check the spelling, or try a larger town nearby.") : "";
            }
        }

        ListView {
            id: list
            x: -6
            width: parent.width + 12
            height: Math.min(contentHeight, 46 * 5)
            visible: count > 0
            clip: true
            interactive: contentHeight > height
            spacing: 2
            model: setup.locator ? setup.locator.results : []

            delegate: PanelRow {
                id: row
                required property var modelData
                required property int index
                readonly property var named: setup.parts(String(modelData.name))
                width: list.width
                title: named.title
                subtitle: named.subtitle
                icon: Defaults.icons.weather
                current: setup.current === index
                onClicked: setup.pick(modelData)
            }
        }
    }
}
