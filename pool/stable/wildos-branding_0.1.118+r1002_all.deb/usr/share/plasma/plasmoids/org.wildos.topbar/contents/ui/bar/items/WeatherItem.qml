pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"

// Weather today, laid out like the other clock: the condition as one of the
// boards' line icons, the place in the muted ink and the temperature
// ("London 14°"; Compact drops the place). The panel adds the conditions,
// today's high and low and the humidity, with the provider's full forecast
// a click away.
//
// config: { type: "weather", source: "<provider|weather|place|id>", place },
// as WeatherSetup returns it.
ReadingItem {
    id: weather

    readonly property var src: loader.item
    readonly property string place: {
        const full = preview ? qsTr("London") : src && src.place.length > 0 ? src.place : String(config.place || "");
        return full.split(",")[0].trim();
    }
    readonly property string temperature: preview ? qsTr("14°") : src ? src.temperature : ""

    function iconFor(name: string): string {
        if (name.length === 0) {
            return "cloud-sun";
        }
        const night = name.indexOf("night") >= 0;
        if (name.indexOf("storm") >= 0) {
            return "cloud-lightning";
        }
        if (name.indexOf("snow") >= 0 || name.indexOf("hail") >= 0 || name.indexOf("freezing") >= 0) {
            return "cloud-snow";
        }
        if (name.indexOf("showers-scattered") >= 0) {
            return "cloud-drizzle";
        }
        if (name.indexOf("showers") >= 0 || name.indexOf("rain") >= 0) {
            return "cloud-rain";
        }
        if (name.indexOf("mist") >= 0 || name.indexOf("fog") >= 0) {
            return "cloud-fog";
        }
        if (name.indexOf("few-clouds") >= 0) {
            return night ? "cloud-moon" : "cloud-sun";
        }
        if (name.indexOf("clear") >= 0) {
            return night ? "moon" : "sun";
        }
        return "cloud";
    }

    label: place
    valueText: temperature
    readonly property string conditions: preview ? qsTr("Partly cloudy") : src ? src.conditions : ""
    accessibleName: {
        if (temperature.length === 0) {
            return qsTr("Weather in %1").arg(place);
        }
        return conditions.length > 0 ? qsTr("Weather in %1, %2, %3").arg(place).arg(temperature).arg(conditions)
            : qsTr("Weather in %1, %2").arg(place).arg(temperature);
    }
    icon: iconFor(preview ? "weather-few-clouds" : src ? src.iconName : "")
    iconColor: Qt.rgba(1, 1, 1, 0.86)
    openText: src && src.creditUrl.length > 0 ? qsTr("Full forecast") : ""
    openIcon: "globe"
    openAction: () => weather.openForecast()

    function openForecast(): void {
        if (host) {
            host.closePopup();
        }
        if (src && src.creditUrl.length > 0) {
            Qt.openUrlExternally(src.creditUrl);
        }
    }

    Loader {
        id: loader
        active: !weather.preview
        source: "../readings/WeatherSource.qml"
        onLoaded: {
            item.weatherSource = Qt.binding(() => String(weather.config.source || ""));
            item.live = Qt.binding(() => weather.live);
        }
    }

    panel: Component {
        ReadingPanel {
            title: weather.src && weather.src.place.length > 0 ? weather.src.place : weather.place
            value: weather.temperature
            showGraph: false
            accent: weather.accent
            linkText: weather.openText
            rows: {
                const s = weather.src;
                if (!s || !s.ready) {
                    return [{ label: qsTr("Weather"), value: qsTr("Waiting for the forecast") }];
                }
                const list = [];
                if (s.conditions.length > 0) {
                    list.push({ label: qsTr("Now"), value: s.conditions });
                }
                if (s.high.length > 0 && s.low.length > 0) {
                    list.push({ label: qsTr("Today"), value: qsTr("High %1, low %2").arg(s.high).arg(s.low) });
                }
                if (s.humidity.length > 0) {
                    list.push({ label: qsTr("Humidity"), value: s.humidity });
                }
                return list;
            }
            onLinkActivated: weather.openForecast()
            Component.onCompleted: weather.panelOpen = true
            Component.onDestruction: weather.panelOpen = false
        }
    }
}
