pragma ComponentBehavior: Bound

import QtQuick
import WildOS.UI as UI
import "readings"

// The panel a reading opens (board 4.16): the name and the value now, the
// last minute as a graph, a few rows of detail, then "Open Task Manager"
// and a reminder that the reading has a right-click menu. 320 wide with
// 16px padding; the host's popup draws the glass, border and radius around it.
//
// It only shows what it is given, so it stays live by binding to the
// reading that opened it.
Item {
    id: panel

    property string title
    property string value
    property var values: []
    property real minimum: 0
    property real maximum: 100
    property string graphName
    // Readings with nothing worth a minute's graph (Battery, Weather).
    property bool showGraph: true
    // [{ label, value }]
    property var rows: []
    property color accent: "#8fb4ff"
    property string linkText: qsTr("Open Task Manager")
    property string hint: qsTr("Right-click for options")

    signal linkActivated()

    readonly property color ink: "#ffffff"
    readonly property color inkMuted: Qt.rgba(1, 1, 1, 0.68)
    readonly property color inkFaint: Qt.rgba(1, 1, 1, 0.42)

    implicitWidth: 320
    implicitHeight: column.implicitHeight + 32

    Column {
        id: column
        x: 16
        y: 16
        width: panel.width - 32
        spacing: 12

        Item {
            width: parent.width
            height: valueText.implicitHeight

            UI.Label {
                id: titleText
                anchors.left: parent.left
                anchors.right: valueText.left
                anchors.rightMargin: 10
                anchors.baseline: valueText.baseline
                size: 13
                color: panel.inkMuted
                text: panel.title
            }
            UI.Label {
                id: valueText
                anchors.right: parent.right
                size: 28
                font.weight: UI.Style.weightLight
                font.features: { "tnum": 1 }
                color: panel.ink
                elide: Text.ElideNone
                text: panel.value
            }
        }

        Graph {
            visible: panel.showGraph
            width: parent.width
            values: panel.values
            minimum: panel.minimum
            maximum: panel.maximum
            color: panel.accent
            Accessible.role: Accessible.Graphic
            Accessible.name: panel.graphName
        }

        // The board pulls this caption 6px closer to the graph.
        Item {
            visible: panel.showGraph
            width: parent.width
            height: agoText.implicitHeight - 6

            UI.Label {
                id: agoText
                y: -6
                anchors.left: parent.left
                size: 11
                color: panel.inkFaint
                text: qsTr("60 seconds ago")
            }
            UI.Label {
                y: -6
                anchors.right: parent.right
                size: 11
                color: panel.inkFaint
                text: qsTr("Now")
            }
        }

        Repeater {
            model: panel.rows

            Item {
                id: row
                required property var modelData
                width: column.width
                height: Math.max(rowLabel.implicitHeight, rowValue.implicitHeight)

                UI.Label {
                    id: rowLabel
                    anchors.left: parent.left
                    anchors.right: rowValue.left
                    anchors.rightMargin: 12
                    size: 12.5
                    color: panel.inkMuted
                    text: row.modelData.label
                }
                UI.Label {
                    id: rowValue
                    anchors.right: parent.right
                    width: Math.min(implicitWidth, column.width * 0.62)
                    horizontalAlignment: Text.AlignRight
                    size: 12.5
                    font.features: { "tnum": 1 }
                    color: panel.ink
                    text: row.modelData.value
                }
            }
        }

        Rectangle {
            width: parent.width
            height: 1
            color: Qt.rgba(1, 1, 1, 0.10)
        }

        Item {
            width: parent.width
            height: Math.max(link.implicitHeight, hintText.implicitHeight)

            UI.Label {
                id: link
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                size: 12.5
                color: panel.accent
                font.underline: linkMouse.containsMouse
                text: panel.linkText
                visible: text.length > 0

                Accessible.role: Accessible.Link
                Accessible.name: text
                Accessible.onPressAction: panel.linkActivated()

                MouseArea {
                    id: linkMouse
                    anchors.fill: parent
                    anchors.margins: -4
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: panel.linkActivated()
                }
            }
            UI.Label {
                id: hintText
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                size: 12
                color: panel.inkFaint
                text: panel.hint
                visible: text.length > 0
            }
        }
    }

    Keys.onReturnPressed: panel.linkActivated()
    Keys.onEnterPressed: panel.linkActivated()
}
