pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Processor: the ring and "12%" (TopBar.dc), the board 4.16 panel on a click.
ReadingItem {
    id: cpu
    taskManagerPage: "performance/cpu"

    readonly property var src: loader.item
    readonly property real percent: preview ? 12 : src ? src.percent : 0

    label: qsTr("Processor")
    valueText: Format.percent(percent)
    ring: percent / 100

    Loader {
        id: loader
        active: !cpu.preview
        source: "../readings/CpuSource.qml"
        onLoaded: item.live = Qt.binding(() => cpu.live)
    }

    Loader {
        id: top
        active: !cpu.preview && cpu.panelOpen
        source: "../readings/TopApp.qml"
        onLoaded: {
            item.metric = "cpu";
            item.cpuCount = Qt.binding(() => cpu.src ? cpu.src.cpuCount : 1);
            item.active = true;
        }
    }

    panel: Component {
        ReadingPanel {
            title: cpu.label
            value: cpu.valueText
            values: cpu.src ? cpu.src.values : []
            accent: cpu.accent
            graphName: qsTr("Processor use over the last minute")
            rows: [
                { label: qsTr("Temperature"), value: cpu.src && !isNaN(cpu.src.temperature) ? Format.degrees(cpu.src.temperature) : qsTr("Not reported") },
                { label: qsTr("Using the most"), value: top.item ? top.item.text(Format.percent) : qsTr("Checking") },
                { label: qsTr("Speed"), value: cpu.src && cpu.src.speed > 0 ? Format.gigahertz(cpu.src.speed) : qsTr("Not reported") }
            ]
            onLinkActivated: cpu.openTaskManager()
            Component.onCompleted: cpu.panelOpen = true
            Component.onDestruction: cpu.panelOpen = false
        }
    }
}
