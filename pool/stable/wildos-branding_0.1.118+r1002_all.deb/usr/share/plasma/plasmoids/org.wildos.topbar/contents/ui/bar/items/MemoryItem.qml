pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Memory: the ring filled to the share in use and "6.2 GB" (TopBar.dc).
// Its panel has the rows Windows' Memory page leads with: in use and
// available, then the app holding the most. Memory has no temperature, and
// ksystemstats has no memory speed, so neither row is shown.
ReadingItem {
    id: memory
    taskManagerPage: "performance/memory"

    readonly property var src: loader.item
    readonly property real usedBytes: preview ? 6.2 * 1073741824 : src ? src.usedBytes : 0
    readonly property real totalBytes: preview ? 16 * 1073741824 : src ? src.totalBytes : 0

    label: qsTr("Memory")
    valueText: Format.gigabytes(usedBytes)
    ring: totalBytes > 0 ? usedBytes / totalBytes : 0

    Loader {
        id: loader
        active: !memory.preview
        source: "../readings/MemorySource.qml"
        onLoaded: item.live = Qt.binding(() => memory.live)
    }

    Loader {
        id: top
        active: !memory.preview && memory.panelOpen
        source: "../readings/TopApp.qml"
        onLoaded: {
            item.metric = "memory";
            item.active = true;
        }
    }

    panel: Component {
        ReadingPanel {
            title: memory.label
            value: memory.valueText
            values: memory.src ? memory.src.values : []
            accent: memory.accent
            graphName: qsTr("Memory in use over the last minute")
            rows: [
                { label: qsTr("In use"), value: qsTr("%1 (%2)").arg(Format.gigabytes(memory.usedBytes)).arg(Format.percent(memory.ring * 100)) },
                { label: qsTr("Available"), value: Format.gigabytes(Math.max(0, memory.totalBytes - memory.usedBytes)) },
                { label: qsTr("Using the most"), value: top.item ? top.item.text(Format.memory) : qsTr("Checking") }
            ]
            onLinkActivated: memory.openTaskManager()
            Component.onCompleted: memory.panelOpen = true
            Component.onDestruction: memory.panelOpen = false
        }
    }
}
