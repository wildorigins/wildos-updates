import QtQuick
import org.kde.plasma.private.battery

// The built-in battery as the quick settings read it: Plasma's battery
// model (UPower through Solid), which reports changes as they happen, so
// nothing here polls.
Item {
    id: source

    readonly property bool hasBattery: battery.hasInternalBatteries && battery.hasCumulative
    readonly property int percent: battery.percent
    readonly property bool pluggedIn: battery.pluggedIn
    readonly property bool charging: battery.state === BatteryControlModel.Charging
    readonly property bool fullyCharged: battery.pluggedIn && battery.state === BatteryControlModel.FullyCharged
    readonly property bool notCharging: battery.pluggedIn && battery.state === BatteryControlModel.NoCharge
    readonly property real remainingMsec: battery.smoothedRemainingMsec

    BatteryControlModel {
        id: battery
    }
}
