import QtQuick
import org.kde.ksysguard.sensors as Sensors

// Memory in use and installed, from ksystemstats, the sensors Task Manager
// reads ("In use" is what it calls memory/physical/used).
Item {
    id: source

    property bool live: false

    readonly property bool ready: used.status === Sensors.Sensor.Ready && Number(total.value) > 0
    readonly property real usedBytes: Number(used.value) || 0
    readonly property real totalBytes: Number(total.value) || 0
    readonly property real percent: ready ? 100 * usedBytes / totalBytes : 0
    readonly property alias values: history.values

    Sensors.Sensor {
        id: used
        sensorId: "memory/physical/used"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: total
        sensorId: "memory/physical/total"
        enabled: source.live
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.percent : NaN
    }
}
