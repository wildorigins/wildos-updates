import QtQuick
import org.kde.plasma.private.mpris as Mpris

// The player Plasma treats as the current one, the one the media keys
// control. Kept out of MediaItem so Settings' previews never load Plasma's
// media module.
Item {
    id: source

    property Item player: null
    readonly property var current: player ? player.model : null
    readonly property bool playing: current !== null && current.playbackStatus === Mpris.PlaybackStatus.Playing
    readonly property bool active: current !== null && current.playbackStatus > Mpris.PlaybackStatus.Stopped

    Repeater {
        model: Mpris.MultiplexerModel {}

        delegate: Item {
            id: entry
            required property var model
            Component.onCompleted: source.player = entry
            Component.onDestruction: {
                if (source.player === entry) {
                    source.player = null;
                }
            }
        }
    }
}
