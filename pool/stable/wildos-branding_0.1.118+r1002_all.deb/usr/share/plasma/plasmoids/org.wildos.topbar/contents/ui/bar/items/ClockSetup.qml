pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Templates as T
import WildOS.UI as UI
import org.wildos.shell as WildOS
import ".."
import "../Defaults.js" as Defaults

// The second step of adding Another clock, inside the Add panel: find a
// city by name, region or time zone and pick it. Each row gives the time
// there now, so the right one is easy to tell.
Item {
    id: setup

    signal done(var config)
    signal cancelled()

    readonly property var all: WildOS.TopBarSettings.cities()
    property int current: 0
    readonly property var matches: {
        const q = field.text.trim().toLowerCase();
        if (q.length === 0) {
            return all;
        }
        return all.filter(c => c.city.toLowerCase().indexOf(q) >= 0 || c.region.toLowerCase().indexOf(q) >= 0
            || c.zone.toLowerCase().indexOf(q.replace(/ /g, "_")) >= 0);
    }
    onMatchesChanged: {
        current = 0;
        list.positionViewAtBeginning();
    }

    // The clock's own minute tick is not running here; one is enough to
    // keep the times in the list right while it is open.
    property int tick: 0
    Timer {
        interval: 60000 - (Date.now() % 60000) + 50
        running: true
        repeat: true
        onTriggered: {
            setup.tick++;
            interval = 60000 - (Date.now() % 60000) + 50;
        }
    }

    implicitWidth: 288
    implicitHeight: column.implicitHeight

    function pick(index: int): void {
        const c = matches[index];
        if (c) {
            done({ type: "clock", zone: c.zone, city: c.city });
        }
    }

    Component.onCompleted: field.focusField()

    Column {
        id: column
        width: parent.width
        spacing: 12

        Row {
            spacing: 8

            Rectangle {
                width: 22
                height: 22
                radius: 6
                anchors.verticalCenter: parent.verticalCenter
                color: back.pressed ? Qt.rgba(1, 1, 1, 0.13) : back.containsMouse ? Qt.rgba(1, 1, 1, 0.09) : "transparent"
                Accessible.role: Accessible.Button
                Accessible.name: qsTr("Back")

                UI.Glyph {
                    anchors.centerIn: parent
                    width: 14
                    height: 14
                    path: Defaults.icons.back
                    color: "#ffffff"
                }

                MouseArea {
                    id: back
                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: setup.cancelled()
                }
            }

            UI.Label {
                anchors.verticalCenter: parent.verticalCenter
                text: qsTr("Another clock")
                size: 13
                color: "#ffffff"
                font.weight: UI.Style.weightSemiBold
            }
        }

        PanelField {
            id: field
            width: parent.width
            placeholder: qsTr("Find a city")
            onAccepted: setup.pick(setup.current)
            onDownPressed: {
                setup.current = Math.min(setup.matches.length - 1, setup.current + 1);
                list.positionViewAtIndex(setup.current, ListView.Contain);
            }
            onUpPressed: {
                setup.current = Math.max(0, setup.current - 1);
                list.positionViewAtIndex(setup.current, ListView.Contain);
            }
            onEscapePressed: setup.cancelled()
        }

        UI.Label {
            visible: setup.matches.length === 0
            width: parent.width
            text: qsTr("No city by that name. Try the country or a nearby city.")
            wrapMode: Text.Wrap
            size: 12.5
            color: Qt.rgba(1, 1, 1, 0.68)
        }

        ListView {
            id: list
            visible: setup.matches.length > 0
            x: -6
            width: parent.width + 12
            height: Math.min(contentHeight, 46 * 8)
            clip: true
            // The line icons are curve-rendered shapes, which the list's
            // clip does not cut; drawing the list as one layer does.
            layer.enabled: true
            spacing: 2
            boundsBehavior: Flickable.StopAtBounds
            model: setup.matches
            reuseItems: true

            delegate: PanelRow {
                required property var modelData
                required property int index
                width: ListView.view.width
                icon: Defaults.icons.clock
                title: modelData.city
                subtitle: qsTr("%1, %2").arg(modelData.region.replace(/_/g, " ")).arg(modelData.text)
                trailing: {
                    setup.tick;
                    return WildOS.TopBarSettings.timeIn(modelData.zone, UI.TimeFormat.shortFormat);
                }
                current: index === setup.current
                onClicked: setup.pick(index)
            }

            T.ScrollBar.vertical: UI.ScrollBar {}
        }
    }
}
