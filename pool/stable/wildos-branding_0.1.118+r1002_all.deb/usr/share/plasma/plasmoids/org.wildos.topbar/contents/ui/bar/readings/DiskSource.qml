import QtQuick
import org.kde.ksysguard.sensors as Sensors

// Disk activity (bytes read and written a second) and space across the
// mounted drives, from ksystemstats' "all disks" sensors.
Item {
    id: source

    property bool live: false

    readonly property bool ready: read.status === Sensors.Sensor.Ready
    readonly property real readRate: Number(read.value) || 0
    readonly property real writeRate: Number(write.value) || 0
    readonly property real freeBytes: Number(free.value) || 0
    readonly property real totalBytes: Number(total.value) || 0
    readonly property alias values: history.values

    Sensors.Sensor {
        id: read
        sensorId: "disk/all/read"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: write
        sensorId: "disk/all/write"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: free
        sensorId: "disk/all/free"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: total
        sensorId: "disk/all/total"
        enabled: source.live
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.readRate + source.writeRate : NaN
    }
}
