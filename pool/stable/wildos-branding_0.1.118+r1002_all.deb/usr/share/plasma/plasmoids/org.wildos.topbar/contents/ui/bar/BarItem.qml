import QtQuick

// One entry of the layout on the bar: loads bar/items/<Type>Item.qml for
// its "type" and hands it what every item gets (see the item contract in
// the top bar brief). Types with no file yet, or a file that fails to load,
// take no room.
Item {
    id: slot

    property var config: ({})
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property bool editing: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property string type: config && config.type ? String(config.type) : ""
    readonly property Item item: loader.item
    readonly property bool shown: item !== null && item.shown === true
    readonly property string accessibleName: item && item.accessibleName ? item.accessibleName : ""
    readonly property string group: groupOf(type)

    // Dividers go between neighbours of different groups, which gives the
    // board's search | launchers | media | gauges | network | disk |
    // battery | clock | weather.
    function groupOf(t: string): string {
        switch (t) {
        case "path":
        case "clipboard":
        case "capture":
            return "launchers";
        case "cpu":
        case "memory":
        case "gpu":
        case "cooler":
            return "gauges";
        default:
            return t;
        }
    }

    function fileFor(t: string): string {
        const names = {
            search: "Search", path: "Path", clipboard: "Clipboard", capture: "Capture", media: "Media",
            cpu: "Cpu", memory: "Memory", gpu: "Gpu", network: "Network", disk: "Disk",
            battery: "Battery", clock: "Clock", weather: "Weather", cooler: "Cooler"
        };
        return names[t] ? Qt.resolvedUrl("items/" + names[t] + "Item.qml") : "";
    }

    function activate(): void {
        if (item && typeof item.activate === "function") {
            item.activate();
        }
    }

    // Readings, the clock and the gauges show only their icon and number
    // while editing; launchers keep their names (board 4.17).
    readonly property bool itemCompact: compact || vertical
        || (editing && ["search", "path", "clipboard", "capture", "media"].indexOf(type) < 0)

    implicitWidth: item ? item.implicitWidth : 0
    implicitHeight: item ? item.implicitHeight : 0

    Loader {
        id: loader
        anchors.centerIn: parent
        width: item ? item.implicitWidth : 0
        height: item ? item.implicitHeight : 0
    }

    function load(): void {
        const url = fileFor(type);
        if (url.length === 0) {
            loader.source = "";
            return;
        }
        loader.setSource(url, {
            config: slot.config,
            compact: slot.itemCompact,
            vertical: slot.vertical,
            live: slot.live,
            preview: slot.preview,
            host: slot.host,
            accent: slot.accent,
            overclock: slot.overclock
        });
    }

    onTypeChanged: load()
    Component.onCompleted: load()

    Binding { target: loader.item; property: "config"; value: slot.config; when: loader.item !== null }
    Binding { target: loader.item; property: "compact"; value: slot.itemCompact; when: loader.item !== null }
    Binding { target: loader.item; property: "vertical"; value: slot.vertical; when: loader.item !== null }
    Binding { target: loader.item; property: "live"; value: slot.live; when: loader.item !== null }
    Binding { target: loader.item; property: "preview"; value: slot.preview; when: loader.item !== null }
    Binding { target: loader.item; property: "host"; value: slot.host; when: loader.item !== null }
    Binding { target: loader.item; property: "accent"; value: slot.accent; when: loader.item !== null }
    Binding { target: loader.item; property: "overclock"; value: slot.overclock; when: loader.item !== null }
    // Only some items draw differently while editing (Now playing drops
    // the artist and stands in for a player that is not there).
    Binding {
        target: loader.item
        property: "editing"
        value: slot.editing
        when: loader.item !== null && loader.item.editing !== undefined
    }
}
