pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Network speed as TopBar.dc draws it: a 12px down arrow, the download, an
// up arrow, the upload, then the unit once in the faint ink, 5px apart.
// Kilobytes below 0.1 MB/s, one decimal throughout.
ReadingItem {
    id: network
    taskManagerPage: "performance/network"

    readonly property var src: loader.item
    readonly property real download: preview ? 2.4 * 1048576 : src ? src.download : 0
    readonly property real upload: preview ? 0.3 * 1048576 : src ? src.upload : 0
    readonly property var unit: Format.rateUnit(Math.max(download, upload))

    // The board draws no name here, only the arrows.
    label: ""
    accessibleName: qsTr("Network speed, download %1, upload %2").arg(Format.rate(download)).arg(Format.rate(upload))
    icon: vertical ? "arrow-down" : ""
    iconSize: 12
    iconColor: Qt.rgba(1, 1, 1, 0.55)
    content: vertical ? null : arrows

    Component {
        id: arrows
        Row {
            spacing: 5
            LineIcon {
                anchors.verticalCenter: parent.verticalCenter
                name: "arrow-down"
                size: 12
                color: Qt.rgba(1, 1, 1, 0.55)
            }
            ReadingText {
                figures: true
                text: Format.rateNumber(network.download, network.unit)
            }
            LineIcon {
                anchors.verticalCenter: parent.verticalCenter
                name: "arrow-up"
                size: 12
                color: Qt.rgba(1, 1, 1, 0.55)
            }
            ReadingText {
                figures: true
                text: Format.rateNumber(network.upload, network.unit)
            }
            ReadingText {
                color: Qt.rgba(1, 1, 1, 0.42)
                text: network.unit.unit
            }
        }
    }

    Loader {
        id: loader
        active: !network.preview
        source: "../readings/NetworkSource.qml"
        onLoaded: item.live = Qt.binding(() => network.live)
    }

    // The graph scales to the busiest second of the minute, as Task
    // Manager's does, with a floor so an idle line stays near the bottom.
    readonly property real graphMaximum: {
        const list = src ? src.values : [];
        let top = 128 * 1024;
        for (let i = 0; i < list.length; ++i) {
            top = Math.max(top, list[i] * 1.15);
        }
        return top;
    }

    panel: Component {
        ReadingPanel {
            title: qsTr("Network speed")
            value: Format.rate(network.download)
            values: network.src ? network.src.values : []
            maximum: network.graphMaximum
            accent: network.accent
            graphName: qsTr("Download speed over the last minute")
            rows: [
                { label: qsTr("Download"), value: Format.rate(network.download) },
                { label: qsTr("Upload"), value: Format.rate(network.upload) }
            ]
            onLinkActivated: network.openTaskManager()
            Component.onCompleted: network.panelOpen = true
            Component.onDestruction: network.panelOpen = false
        }
    }
}
