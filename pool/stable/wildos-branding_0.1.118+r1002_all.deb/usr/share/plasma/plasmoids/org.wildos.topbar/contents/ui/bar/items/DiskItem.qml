pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Disk, in the language of the other gauges: the ring filled to the space
// used, "Disk", then the space left ("212 GB free"; Compact keeps the
// number). The panel leads with activity, read plus write right now, with
// its last minute, and the app reading and writing the most.
ReadingItem {
    id: disk
    taskManagerPage: "performance/disk-system"

    readonly property var src: loader.item
    readonly property real freeBytes: preview ? 212 * 1073741824 : src ? src.freeBytes : 0
    readonly property real totalBytes: preview ? 476 * 1073741824 : src ? src.totalBytes : 0
    readonly property real activity: preview ? 1.2 * 1048576 : src ? src.readRate + src.writeRate : 0

    label: qsTr("Disk")
    valueText: totalBytes <= 0 ? "" : compact ? Format.capacity(freeBytes) : qsTr("%1 free").arg(Format.capacity(freeBytes))
    accessibleName: qsTr("Disk, %1 free, %2 activity").arg(Format.capacity(freeBytes)).arg(Format.rate(activity))
    ring: totalBytes > 0 ? 1 - freeBytes / totalBytes : 0

    Loader {
        id: loader
        active: !disk.preview
        source: "../readings/DiskSource.qml"
        onLoaded: item.live = Qt.binding(() => disk.live)
    }

    Loader {
        id: top
        active: !disk.preview && disk.panelOpen
        source: "../readings/TopApp.qml"
        onLoaded: {
            item.metric = "disk";
            item.active = true;
        }
    }

    readonly property real graphMaximum: {
        const list = src ? src.values : [];
        let top = 1048576;
        for (let i = 0; i < list.length; ++i) {
            top = Math.max(top, list[i] * 1.15);
        }
        return top;
    }

    panel: Component {
        ReadingPanel {
            title: disk.label
            value: Format.rate(disk.activity)
            values: disk.src ? disk.src.values : []
            maximum: disk.graphMaximum
            accent: disk.accent
            graphName: qsTr("Disk activity over the last minute")
            rows: [
                { label: qsTr("Read"), value: Format.rate(disk.src ? disk.src.readRate : 0) },
                { label: qsTr("Write"), value: Format.rate(disk.src ? disk.src.writeRate : 0) },
                { label: qsTr("Free space"), value: qsTr("%1 of %2").arg(Format.capacity(disk.freeBytes)).arg(Format.capacity(disk.totalBytes)) },
                { label: qsTr("Using the most"), value: top.item ? top.item.text(Format.rate) : qsTr("Checking") }
            ]
            onLinkActivated: disk.openTaskManager()
            Component.onCompleted: disk.panelOpen = true
            Component.onDestruction: disk.panelOpen = false
        }
    }
}
