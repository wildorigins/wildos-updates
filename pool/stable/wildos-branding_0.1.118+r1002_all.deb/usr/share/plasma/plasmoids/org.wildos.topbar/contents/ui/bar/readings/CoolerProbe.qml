import QtQuick
import org.kde.plasma.workspace.dbus as DBus

// Whether a supported cooler is connected, from wildos-cooler's service on
// the system bus. udev starts the service when a cooler is plugged in and
// it leaves when the cooler goes, so watching its name is enough to notice
// both. Describe is asked once each time the name appears, never on a
// timer: asking keeps the service from leaving on a PC without a cooler.
Item {
    id: probe

    property bool active: true

    readonly property bool running: watcher.registered
    property bool present: false
    property bool fansOnCooler: true
    property string model: ""

    function unwrap(v: var): var {
        return v !== null && v !== undefined && typeof v === "object" && v.value !== undefined ? v.value : v;
    }

    function describe(): void {
        if (!active || !watcher.registered) {
            present = false;
            return;
        }
        const reply = DBus.SystemBus.asyncCall({
            service: "io.wildos.Cooler",
            path: "/io/wildos/Cooler",
            iface: "io.wildos.Cooler1",
            member: "Describe"
        });
        reply.finished.connect(() => {
            if (reply.isError) {
                probe.present = false;
                return;
            }
            const info = probe.unwrap(reply.value) || {};
            probe.present = probe.unwrap(info.present) === true;
            probe.fansOnCooler = probe.unwrap(info.fansOnCooler) !== false;
            probe.model = String(probe.unwrap(info.model) || "");
        });
    }

    DBus.DBusServiceWatcher {
        id: watcher
        busType: DBus.BusType.System
        watchedService: "io.wildos.Cooler"
        onRegisteredChanged: probe.describe()
    }

    onActiveChanged: describe()
    Component.onCompleted: describe()
}
