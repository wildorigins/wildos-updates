import QtQuick
import WildOS.UI as UI

// A row in the Add panel (board 4.17): 44px, radius 8, 0 10px padding, a
// 28px tile (radius 7, rgba(255,255,255,0.07)) holding a 15px icon, then
// the name at 13px over a 11.5px line at 0.68. Lit at 0.08 on hover or
// when the keyboard is on it.
Rectangle {
    id: row

    property string title
    property string subtitle
    property string icon
    property string trailing
    property bool current: false

    signal clicked()

    implicitHeight: 44
    radius: 8
    color: current || mouse.containsMouse ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
    Accessible.role: Accessible.ListItem
    Accessible.name: subtitle.length > 0 ? title + ", " + subtitle : title

    Rectangle {
        id: tile
        x: 10
        anchors.verticalCenter: parent.verticalCenter
        width: 28
        height: 28
        radius: 7
        color: Qt.rgba(1, 1, 1, 0.07)

        UI.Glyph {
            anchors.centerIn: parent
            width: 15
            height: 15
            path: row.icon
            color: "#ffffff"
        }
    }

    Column {
        anchors.left: tile.right
        anchors.leftMargin: 12
        anchors.right: end.left
        anchors.rightMargin: end.visible ? 10 : 0
        anchors.verticalCenter: parent.verticalCenter
        spacing: 1

        UI.Label {
            width: parent.width
            text: row.title
            size: 13
            color: "#ffffff"
        }

        UI.Label {
            width: parent.width
            visible: row.subtitle.length > 0
            text: row.subtitle
            size: 11.5
            color: Qt.rgba(1, 1, 1, 0.68)
        }
    }

    UI.Label {
        id: end
        anchors.right: parent.right
        anchors.rightMargin: 10
        anchors.verticalCenter: parent.verticalCenter
        visible: row.trailing.length > 0
        text: row.trailing
        size: 12.5
        color: Qt.rgba(1, 1, 1, 0.68)
        font.features: { "tnum": 1 }
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: row.clicked()
    }
}
