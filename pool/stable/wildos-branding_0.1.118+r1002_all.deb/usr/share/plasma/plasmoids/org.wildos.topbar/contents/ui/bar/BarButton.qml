import QtQuick
import WildOS.UI as UI

// One thing on the top bar as the boards draw it (TopBar.dc and the rest):
// 24px tall (20 in Compact), radius 6, 0 7px padding, 6px between icon and
// text, 12.5px text, rgba(255,255,255,0.09) on hover and 0.13 while pressed
// or while its panel is open. Put the icon and labels inside it; they are
// laid out in a row and centred.
//
// The bar is always the dark glass of the boards, so text and icons on it
// use the board's whites (ink, muted, faint) rather than the light or dark
// Style colours.
Item {
    id: button

    default property alias content: row.data

    property bool compact: false
    property bool vertical: false
    // A panel that belongs to it is showing (board 4.16 keeps the pressed
    // fill under Processor while its panel is open).
    property bool open: false
    // Settings previews draw the bar without acting on anything.
    property bool preview: false
    property real leftPadding: 7
    property real rightPadding: 7
    property real spacing: 6
    // Search is a fixed 26px square (22 in Compact) with no padding.
    property real fixedWidth: 0
    property string tip: ""
    // A right click goes to the bar (its menu offers Edit the top bar and
    // Remove) unless the item has a menu of its own and sets this.
    property bool ownMenu: false

    readonly property real itemHeight: compact ? 20 : 24
    readonly property bool hovered: hover.hovered
    readonly property bool pressed: mouse.pressed

    readonly property color ink: "#ffffff"
    readonly property color inkMuted: Qt.rgba(1, 1, 1, 0.68)
    readonly property color inkFaint: Qt.rgba(1, 1, 1, 0.42)
    readonly property color iconInk: Qt.rgba(1, 1, 1, 0.86)
    readonly property real textSize: 12.5

    signal clicked()
    signal rightClicked(real x, real y)

    implicitHeight: vertical ? Math.max(itemHeight, row.implicitHeight + 4) : itemHeight
    implicitWidth: vertical ? itemHeight
        : fixedWidth > 0 ? fixedWidth : Math.ceil(row.implicitWidth + leftPadding + rightPadding)

    Rectangle {
        anchors.fill: parent
        radius: 6
        color: button.pressed || button.open ? Qt.rgba(1, 1, 1, 0.13)
            : button.hovered ? Qt.rgba(1, 1, 1, 0.09) : Qt.rgba(1, 1, 1, 0)
        Behavior on color {
            enabled: button.hovered
            ColorAnimation { duration: UI.Style.hoverDuration }
        }
    }

    // Under the content, so controls inside the button (Now playing's
    // previous, play and next) take their own clicks.
    MouseArea {
        id: mouse
        anchors.fill: parent
        enabled: !button.preview
        acceptedButtons: button.ownMenu ? Qt.LeftButton | Qt.RightButton : Qt.LeftButton
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton) {
                button.rightClicked(mouse.x, mouse.y);
            } else {
                button.clicked();
            }
        }
    }

    HoverHandler {
        id: hover
        enabled: !button.preview
    }

    Row {
        id: row
        anchors.centerIn: parent
        // Padding is asymmetric for Now playing (0 2px 0 5px).
        anchors.horizontalCenterOffset: button.vertical || button.fixedWidth > 0 ? 0 : (button.leftPadding - button.rightPadding) / 2
        spacing: button.spacing
    }

    UI.Tooltip {
        ownWindow: true
        visible: button.tip.length > 0 && button.hovered && !button.pressed && !button.open
        text: button.tip
    }
}
