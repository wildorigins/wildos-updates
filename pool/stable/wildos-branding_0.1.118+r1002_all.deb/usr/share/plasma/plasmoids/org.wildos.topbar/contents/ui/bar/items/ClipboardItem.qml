import QtQuick
import WildOS.UI as UI
import ".."
import "../Defaults.js" as Defaults

// Clipboard: opens clipboard history, as Win+V does.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property bool shown: true
    readonly property string accessibleName: qsTr("Clipboard history")

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    function activate(): void {
        if (!preview && host) {
            host.openClipboard();
        }
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        tip: qsTr("Clipboard history (Win+V)")
        onClicked: item.activate()

        UI.Glyph {
            anchors.verticalCenter: parent.verticalCenter
            width: 14
            height: 14
            path: Defaults.icons.clipboard
            color: button.iconInk
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical
            text: qsTr("Clipboard")
            size: button.textSize
            color: button.ink
        }
    }
}
