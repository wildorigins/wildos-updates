import QtQuick
import WildOS.UI as UI
import ".."
import "../Defaults.js" as Defaults

// Capture: opens the screenshot toolbar (wildos-capture), as Print Screen
// and Win+Shift+S do.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property bool shown: true
    readonly property string accessibleName: qsTr("Capture")

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    function activate(): void {
        if (!preview && host) {
            host.openCapture();
        }
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        tip: qsTr("Capture (Win+Shift+S)")
        onClicked: item.activate()

        UI.Glyph {
            anchors.verticalCenter: parent.verticalCenter
            width: 14
            height: 14
            path: Defaults.icons.capture
            color: button.iconInk
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical
            text: qsTr("Capture")
            size: button.textSize
            color: button.ink
        }
    }
}
