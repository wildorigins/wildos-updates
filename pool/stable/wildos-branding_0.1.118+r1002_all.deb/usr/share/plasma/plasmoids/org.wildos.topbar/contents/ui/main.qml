import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import QtQuick.Templates as T
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as P5Support
import org.kde.taskmanager as TaskManager
import org.wildos.shell as WildOS
import WildOS.UI as UI
import "bar"
import "bar/Defaults.js" as Defaults

// The top bar (Settings > Personalisation > Top bar): a panel of its own on
// each screen holding only this widget, which draws the whole bar. Plasma
// gives it the reserved space, hiding at the edge and the shortcut; this
// file joins the bar (bar/BarView.qml, which Settings also draws for its
// previews) to the system: what its items open, their panels, the bar's
// menu, edit mode with the dimmed desktop, and saving the layout.
PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    Plasmoid.constraintHints: Plasmoid.CanFillArea
    preferredRepresentation: fullRepresentation
    activationTogglesExpanded: false

    readonly property string screenName: Screen.name
    // Plasma's screen 0 is the main display; its bar uses the shared
    // layout and answers Settings' "Edit the top bar".
    readonly property bool isMain: !Plasmoid.containment || Plasmoid.containment.screen <= 0
    readonly property string layoutScreen: isMain ? "" : screenName
    readonly property rect screenGeometry: Plasmoid.containment ? Plasmoid.containment.screenGeometry : Qt.rect(0, 0, 0, 0)

    readonly property string edge: Plasmoid.location === PlasmaCore.Types.LeftEdge ? "left"
        : Plasmoid.location === PlasmaCore.Types.RightEdge ? "right" : "top"
    readonly property bool vertical: edge !== "top"
    readonly property bool compact: WildOS.TopBarSettings.size === "compact"

    // Read by the panel (wildos-shell Panel.qml): how thick to make the bar
    // and whether to blur behind it.
    readonly property int wantedThickness: editing ? 42 : compact ? 24 : 32
    readonly property string look: WildOS.TopBarSettings.look

    property Item bar: null
    property Item representation: null

    // The saved layout, replaced only when it really changes so the items
    // are not all rebuilt for every settings change.
    property var savedLayout: Defaults.defaultLayout(WildOS.TopBarSettings.defaultProjectsPath())
    function readLayout(): void {
        const next = Defaults.normalise(WildOS.TopBarSettings.layoutFor(layoutScreen), WildOS.TopBarSettings.defaultProjectsPath());
        if (!Defaults.same(next, savedLayout)) {
            savedLayout = next;
        }
    }
    Connections {
        target: WildOS.TopBarSettings
        function onRevisionChanged() { root.readLayout(); }
        function onEditRequestedChanged() { root.editRequestCheck(); }
    }
    onLayoutScreenChanged: readLayout()

    function saveLayout(layout: var): void {
        WildOS.TopBarSettings.setLayout(layoutScreen, layout);
        savedLayout = Defaults.copy(layout);
    }

    // Edit mode (board 4.17)

    property bool editing: false
    property var draft: null
    // The region whose plus button is open, "" for none.
    property string adding: ""
    property Item addAnchor: null
    readonly property var shownLayout: editing && draft ? draft : savedLayout

    function startEdit(): void {
        if (editing) {
            return;
        }
        closePopup();
        draft = Defaults.copy(savedLayout);
        editing = true;
        WildOS.TopBarSettings.editingScreen = screenName;
    }

    function endEdit(): void {
        editing = false;
        draft = null;
        adding = "";
        addAnchor = null;
        if (WildOS.TopBarSettings.editingScreen === screenName) {
            WildOS.TopBarSettings.editingScreen = "";
        }
    }

    function saveEdit(): void {
        if (draft && !Defaults.same(draft, savedLayout)) {
            saveLayout(draft);
        }
        endEdit();
    }

    function discardEdit(): void {
        endEdit();
    }

    // Settings turns the bar on before asking for edit mode, so a bar that
    // has only just loaded still takes a request from the last few seconds.
    property double handledEditRequest: 0
    function editRequestCheck(): void {
        const at = WildOS.TopBarSettings.editRequested;
        if (!isMain || at <= 0 || at === handledEditRequest) {
            return;
        }
        handledEditRequest = at;
        if (Math.abs(Date.now() - at) < 10000) {
            startEdit();
        }
    }
    Timer {
        id: startupEditCheck
        interval: 600
        onTriggered: root.editRequestCheck()
    }

    // Changes from the bar: in edit mode to the draft, otherwise saved at
    // once (dropping a folder on the bar, Remove from its menu).
    function applyChange(layout: var): void {
        if (editing) {
            draft = layout;
        } else {
            saveLayout(layout);
        }
    }

    function removeAt(region: string, index: int): void {
        if (index >= 0) {
            applyChange(Defaults.removed(shownLayout, region, index));
        }
    }

    function addEntries(region: string, entries: var): void {
        // Next to the plus button: the end of the left and middle, the start
        // of the right.
        applyChange(Defaults.inserted(shownLayout, region, region === "right" ? 0 : -1, entries));
        adding = "";
        addAnchor = null;
    }

    // Whether readings run: only while the bar can be seen.

    property bool hovered: false
    readonly property bool autoHidden: WildOS.TopBarSettings.autoHide
        && !hovered && !popup.visible && !editing && !(bar && bar.activeFocus)
    readonly property bool live: WildOS.TopBarSettings.enabled && !coveredByFullScreen && !autoHidden

    // A full-screen app on this screen covers the bar while it is the
    // active window (an inactive one drops below the panels).
    property bool coveredByFullScreen: false
    function updateCovered(): void {
        const index = tasks.activeTask;
        coveredByFullScreen = index !== undefined && index !== null && index.valid
            && tasks.data(index, TaskManager.AbstractTasksModel.IsFullScreen) === true;
    }

    TaskManager.VirtualDesktopInfo { id: desktops }
    TaskManager.ActivityInfo { id: activities }

    TaskManager.TasksModel {
        id: tasks
        filterByScreen: true
        screenGeometry: root.screenGeometry
        filterByVirtualDesktop: true
        virtualDesktop: desktops.currentDesktop
        filterByActivity: true
        activity: activities.currentActivity
        filterMinimized: true
        filterHidden: true
        groupMode: TaskManager.TasksModel.GroupDisabled
        onActiveTaskChanged: root.updateCovered()
        onDataChanged: root.updateCovered()
        onCountChanged: root.updateCovered()
    }

    // What the items do (the host in the brief's item contract)

    P5Support.DataSource {
        id: shell
        engine: "executable"
        onNewData: source => disconnectSource(source)
    }

    function run(command: string): void {
        shell.connectSource(command);
    }

    function safeName(name: string): bool {
        return /^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)?$/.test(name);
    }

    // The same global shortcut the keys trigger, so the bar does exactly
    // what Win+S, Win+V and Print Screen do; the app itself if the shortcut
    // service cannot be reached.
    function invokeShortcut(component: string, action: string, fallback: string): void {
        run("dbus-send --session --print-reply --type=method_call --dest=org.kde.kglobalaccel /component/" + component
            + " org.kde.kglobalaccel.Component.invokeShortcut string:'" + action + "' >/dev/null 2>&1 || " + fallback);
    }

    readonly property QtObject host: QtObject {
        function openSearch(): void {
            root.invokeShortcut("plasmashell", "activate application launcher",
                "dbus-send --session --type=method_call --dest=org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.activateLauncherMenu");
        }
        function openClipboard(): void {
            root.invokeShortcut("org_wildos_clipboard_desktop", "_launch", "kstart --application org.wildos.clipboard");
        }
        function openCapture(): void {
            root.invokeShortcut("org_wildos_screenshot_desktop", "_launch", "kstart --application org.wildos.screenshot");
        }
        function openPath(path: string): void {
            const url = path.startsWith("file:") ? path : "file://" + path.split("/").map(encodeURIComponent).join("/");
            Qt.openUrlExternally(url);
        }
        function openTaskManager(page: string): void {
            if (page && root.safeName(page)) {
                root.run("kstart --desktopfile org.wildos.taskmanager -- wildos-taskmanager --page " + page);
            } else {
                root.run("kstart --application org.wildos.taskmanager");
            }
        }
        function openSettings(page: string): void {
            if (root.safeName(page)) {
                root.run("kstart --desktopfile org.wildos.settings -- wildos-settings --page " + page);
            }
        }
        function launch(desktopId: string): void {
            if (root.safeName(desktopId)) {
                root.run("kstart --application " + desktopId);
            }
        }
        function showPopup(anchor: Item, component: Component, properties: var): void {
            root.showPopup(anchor, component, properties);
        }
        function closePopup(): void {
            root.closePopup();
        }
        function contextMenu(anchor: Item, entries: var): void {
            root.openMenu(anchor, entries);
        }
        function startEdit(): void {
            root.startEdit();
        }
        function removeItem(item: Item): void {
            const at = root.bar ? root.bar.locate(item) : null;
            if (at) {
                root.removeAt(at.region, at.index);
            }
        }
    }

    // The keyboard (Super+Alt+B, set on the main display's bar by Settings)

    function focusBar(): void {
        if (!bar || editing) {
            return;
        }
        if (Plasmoid.containment) {
            Plasmoid.containment.status = PlasmaCore.Types.AcceptingInputStatus;
        }
        Qt.callLater(() => root.bar.forceActiveFocus(Qt.ShortcutFocusReason));
    }

    function leaveBar(): void {
        if (bar) {
            bar.focus = false;
        }
        if (Plasmoid.containment) {
            Plasmoid.containment.status = PlasmaCore.Types.PassiveStatus;
        }
    }

    Connections {
        target: Plasmoid
        function onActivated() { root.focusBar(); }
    }

    // Menus

    function openMenu(anchor: Item, entries: var): void {
        if (!representation) {
            return;
        }
        const menu = representation.menu;
        menu.entries = entries;
        const p = anchor ? anchor.mapToItem(representation, 0, 0) : Qt.point(0, 0);
        const w = anchor ? anchor.width : 0;
        const h = anchor ? anchor.height : 0;
        if (edge === "left") {
            menu.x = representation.width + 6;
            menu.y = Math.round(p.y);
        } else if (edge === "right") {
            menu.x = -menu.implicitWidth - 6;
            menu.y = Math.round(p.y);
        } else {
            menu.x = Math.round(Math.max(8 - representation.mapToGlobal(0, 0).x + screenGeometry.x,
                Math.min(representation.width - menu.implicitWidth - 8, p.x + w / 2 - menu.implicitWidth / 2)));
            menu.y = representation.height + 6;
        }
        menu.open();
    }

    // The bar's own menu, or an item's when it has one (the readings).
    function barMenu(region: string, index: int, x: real, y: real): void {
        const slot = region.length > 0 && bar ? bar.slotAt(region, index) : null;
        const item = slot ? slot.barItem.item : null;
        if (item && typeof item.openMenu === "function" && !editing) {
            item.openMenu();
            return;
        }
        const entries = [];
        if (slot) {
            entries.push({ text: qsTr("Remove from the top bar"), icon: "unpin", run: () => root.removeAt(region, index) });
            entries.push({ separator: true });
        }
        if (!editing) {
            entries.push({ text: qsTr("Edit the top bar"), icon: "pencil", run: () => root.startEdit() });
        }
        entries.push({ text: qsTr("Top bar settings"), icon: "menu-settings", run: () => root.host.openSettings("topbar") });
        openMenu(slot ? slot.barItem : null, entries);
        if (!slot) {
            const menu = representation.menu;
            if (edge === "top") {
                menu.x = Math.round(Math.max(8, Math.min(representation.width - menu.implicitWidth - 8, x - menu.implicitWidth / 2)));
            } else {
                menu.y = Math.round(y);
            }
        }
    }

    // Reading panels (board 4.16): under the item, 6px below the bar, in
    // rgba(28,30,38,0.96) with radius 12 and a 0.12 edge.

    property Item popupAnchor: null
    property double popupClosedAt: 0
    readonly property int popupShadow: 28

    function showPopup(anchor: Item, component: Component, properties: var): void {
        if (!anchor || !component) {
            return;
        }
        // The press that hid the panel was on the same item: it closes it
        // rather than opening it again.
        if (anchor === popupAnchor && Date.now() - popupClosedAt < 300) {
            return;
        }
        popupLoader.sourceComponent = null;
        popupAnchor = anchor;
        popupLoader.sourceComponent = component;
        if (popupLoader.item && properties) {
            for (const key in properties) {
                popupLoader.item[key] = properties[key];
            }
        }
        placePopup();
        popup.visible = true;
        popup.requestActivate();
        // Like a Windows flyout, the open panel takes the keyboard, so
        // Escape closes it.
        Qt.callLater(() => popupRoot.forceActiveFocus());
    }

    function closePopup(): void {
        popup.visible = false;
    }

    function placePopup(): void {
        if (!popupAnchor || !popupLoader.item) {
            return;
        }
        const g = popupAnchor.mapToGlobal(0, 0);
        const w = popupCard.width;
        const h = popupCard.height;
        const s = screenGeometry;
        const m = popupShadow;
        let x, y;
        if (edge === "top") {
            x = g.x + popupAnchor.width / 2 - w / 2;
            y = s.y + wantedThickness + 6;
        } else {
            x = edge === "left" ? s.x + wantedThickness + 6 : s.x + s.width - wantedThickness - 6 - w;
            y = g.y + popupAnchor.height / 2 - h / 2;
        }
        x = Math.max(s.x + 8, Math.min(s.x + s.width - w - 8, x));
        y = Math.max(s.y + 8, Math.min(s.y + s.height - h - 8, y));
        popup.x = Math.round(x - m);
        popup.y = Math.round(y - m);
    }

    PlasmaCore.Dialog {
        id: popup

        type: PlasmaCore.Dialog.AppletPopup
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        backgroundHints: PlasmaCore.Dialog.NoBackground
        location: PlasmaCore.Types.Floating
        hideOnWindowDeactivate: true
        visible: false
        onVisibleChanged: {
            if (!visible) {
                root.popupClosedAt = Date.now();
                popupLoader.sourceComponent = null;
                Qt.callLater(() => {
                    if (!popup.visible) {
                        root.popupAnchor = null;
                    }
                });
            }
        }

        mainItem: Item {
            id: popupRoot
            width: popupCard.width + 2 * root.popupShadow
            height: popupCard.height + 2 * root.popupShadow
            focus: true
            Keys.onEscapePressed: root.closePopup()

            // The margin that holds the shadow closes the panel like a
            // click anywhere else.
            MouseArea {
                anchors.fill: parent
                onClicked: root.closePopup()
            }

            MultiEffect {
                source: popupCard
                anchors.fill: popupCard
                shadowEnabled: true
                shadowColor: Qt.rgba(0, 0, 0, 0.5)
                shadowBlur: 1
                blurMax: 48
                shadowVerticalOffset: 16
            }

            Rectangle {
                id: popupCard
                x: root.popupShadow
                y: root.popupShadow
                width: popupLoader.item ? popupLoader.item.implicitWidth : 320
                height: popupLoader.item ? popupLoader.item.implicitHeight : 0
                radius: 12
                color: Qt.rgba(28 / 255, 30 / 255, 38 / 255, 0.96)
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.12)
                onHeightChanged: root.placePopup()

                MouseArea {
                    anchors.fill: parent
                }

                Loader {
                    id: popupLoader
                    anchors.fill: parent
                }
            }
        }
    }

    // Edit mode's window: the rest of the screen dimmed
    // (rgba(6,8,12,0.45)), the Add panel under the pressed plus and the
    // Save and Discard bar at the top right. The bar itself stays undimmed
    // in its own panel.

    PlasmaCore.Dialog {
        id: overlay

        type: PlasmaCore.Dialog.AppletPopup
        flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        backgroundHints: PlasmaCore.Dialog.NoBackground
        location: PlasmaCore.Types.Floating
        hideOnWindowDeactivate: false
        visible: root.editing
        x: root.screenGeometry.x + (root.edge === "left" ? 42 : 0)
        y: root.screenGeometry.y + (root.edge === "top" ? 42 : 0)
        onVisibleChanged: {
            if (visible) {
                requestActivate();
                overlayItem.forceActiveFocus();
            }
        }

        mainItem: FocusScope {
            id: overlayItem
            width: Math.max(1, root.screenGeometry.width - (root.vertical ? 42 : 0))
            height: Math.max(1, root.screenGeometry.height - (root.edge === "top" ? 42 : 0))
            focus: true

            Keys.onEscapePressed: {
                if (root.adding.length > 0) {
                    root.adding = "";
                    root.addAnchor = null;
                } else {
                    root.discardEdit();
                }
            }

            Rectangle {
                anchors.fill: parent
                color: Qt.rgba(6 / 255, 8 / 255, 12 / 255, 0.45)
            }

            // A click on the dimmed desktop closes the Add panel; nothing
            // underneath can be used while editing.
            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.AllButtons
                onClicked: {
                    root.adding = "";
                    root.addAnchor = null;
                }
            }

            AddPanel {
                id: addPanel
                visible: root.adding.length > 0
                region: root.adding
                hasBattery: availability.item ? availability.item.battery === true : false
                hasCooler: availability.item ? availability.item.cooler === true : false
                maximumHeight: overlayItem.height - y - 16
                readonly property point anchorAt: {
                    root.adding;
                    if (!root.addAnchor) {
                        return Qt.point(0, 0);
                    }
                    const g = root.addAnchor.mapToGlobal(root.addAnchor.width / 2, root.addAnchor.height / 2);
                    return Qt.point(g.x - overlay.x, g.y - overlay.y);
                }
                x: root.edge === "top" ? Math.round(Math.max(8, Math.min(overlayItem.width - width - 8, anchorAt.x - width / 2)))
                    : root.edge === "left" ? 10 : overlayItem.width - width - 10
                y: root.edge === "top" ? 10 : Math.round(Math.max(8, Math.min(overlayItem.height - 200, anchorAt.y - 40)))
                onVisibleChanged: {
                    if (visible) {
                        reset();
                    }
                }
                onAdded: entries => root.addEntries(root.adding, entries)
                onClosed: {
                    root.adding = "";
                    root.addAnchor = null;
                    overlayItem.forceActiveFocus();
                }
            }

            Loader {
                id: availability
                active: root.editing
                source: "bar/Availability.qml"
            }

            // right 16px, 12px below the 42px bar: 50px tall, radius 12.
            MultiEffect {
                source: toolbar
                anchors.fill: toolbar
                shadowEnabled: true
                shadowColor: Qt.rgba(0, 0, 0, 0.5)
                shadowBlur: 1
                blurMax: 50
                shadowVerticalOffset: 20
            }

            Rectangle {
                id: toolbar
                anchors.right: parent.right
                anchors.rightMargin: 16
                y: 12
                height: 50
                width: toolbarRow.implicitWidth + 26
                radius: 12
                color: Qt.rgba(28 / 255, 30 / 255, 38 / 255, 0.96)
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.12)

                MouseArea {
                    anchors.fill: parent
                }

                Row {
                    id: toolbarRow
                    x: 16
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 12

                    UI.Label {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("Drag to move things. Drag off the bar to remove.")
                        size: 13
                        color: Qt.rgba(1, 1, 1, 0.68)
                    }

                    ToolbarButton {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("Discard")
                        onClicked: root.discardEdit()
                    }

                    ToolbarButton {
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("Save")
                        primary: true
                        accent: root.bar ? root.bar.accent : "#8fb4ff"
                        onClicked: root.saveEdit()
                    }
                }
            }
        }
    }

    // Discard: 30px, 0 14px, radius 7, a 0.16 edge on 0.06. Save: the
    // accent with #10131c text. Both 13px semibold.
    component ToolbarButton: Rectangle {
        id: tb

        property string text
        property bool primary: false
        property color accent: "#8fb4ff"
        signal clicked()

        height: 30
        width: tbLabel.implicitWidth + 28
        radius: 7
        color: primary ? (tbMouse.pressed ? Qt.darker(accent, 1.08) : tbMouse.containsMouse ? Qt.lighter(accent, 1.08) : accent)
            : tbMouse.pressed ? Qt.rgba(1, 1, 1, 0.13) : tbMouse.containsMouse ? Qt.rgba(1, 1, 1, 0.09) : Qt.rgba(1, 1, 1, 0.06)
        border.width: primary ? 0 : 1
        border.color: Qt.rgba(1, 1, 1, 0.16)
        Accessible.role: Accessible.Button
        Accessible.name: text
        Accessible.onPressAction: clicked()

        UI.Label {
            id: tbLabel
            anchors.centerIn: parent
            text: tb.text
            size: 13
            color: tb.primary ? "#10131c" : "#ffffff"
            font.weight: UI.Style.weightSemiBold
        }

        MouseArea {
            id: tbMouse
            anchors.fill: parent
            hoverEnabled: true
            onClicked: tb.clicked()
        }
    }

    fullRepresentation: Item {
        id: full

        readonly property alias menu: menu

        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.minimumWidth: root.vertical ? root.wantedThickness : 0
        Layout.minimumHeight: root.vertical ? 0 : root.wantedThickness

        Component.onCompleted: root.representation = full

        HoverHandler {
            onHoveredChanged: root.hovered = hovered
        }

        // Plasma's panel containment insets its widgets by the theme's panel
        // margins whatever the widget asks for, which left the wallpaper
        // showing at both ends. The bar spans the whole panel window instead,
        // as drawn, so it measures where the containment put it.
        property point origin: Qt.point(0, 0)
        function locate(): void {
            const at = full.mapToItem(null, 0, 0);
            origin = Qt.point(at.x, at.y);
        }
        onWidthChanged: Qt.callLater(locate)
        onHeightChanged: Qt.callLater(locate)
        Connections {
            target: full.Window.window
            function onWidthChanged() { Qt.callLater(full.locate); }
            function onHeightChanged() { Qt.callLater(full.locate); }
        }

        // The shadow the bar casts on the desktop, outside its window
        // (boards 4.15 and 4.20). A Clear bar has nothing to cast one.
        WildOS.BarShadow {
            window: full.Window.window
            edge: root.edge
            enabled: root.look !== "clear"
            color: barView.overclock ? Qt.rgba(1, 40 / 255, 80 / 255, 0.16) : Qt.rgba(0, 0, 0, 0.20)
            offset: barView.overclock ? 8 : 10
            blur: 28
        }

        BarView {
            id: barView
            x: -full.origin.x
            y: -full.origin.y
            width: root.vertical ? full.width : (full.Window.window?.width ?? full.width)
            height: root.vertical ? (full.Window.window?.height ?? full.height) : full.height
            layout: root.shownLayout
            size: WildOS.TopBarSettings.size
            edge: root.edge
            look: root.look
            live: root.live
            editing: root.editing
            addingTo: root.adding
            host: root.host
            Component.onCompleted: {
                root.bar = barView;
                Qt.callLater(full.locate);
            }
            onEdited: layout => root.applyChange(layout)
            onAddRequested: (region, anchor) => {
                root.adding = region;
                root.addAnchor = anchor;
            }
            onMenuRequested: (region, index, x, y) => root.barMenu(region, index, x, y)
            onKeyboardLeft: root.leaveBar()
            onPathsDropped: (urls, region, index) => {
                const entries = urls.map(u => ({ type: "path", path: decodeURIComponent(u.replace(/^file:\/\//, "")) }));
                root.applyChange(Defaults.inserted(root.shownLayout, region, index, entries));
            }
        }

        UI.Menu {
            id: menu
            popupType: T.Popup.Window
            minimumWidth: 240
        }
    }

    Component.onCompleted: {
        readLayout();
        updateCovered();
        startupEditCheck.start();
    }

    Component.onDestruction: {
        if (editing) {
            endEdit();
        }
    }
}
