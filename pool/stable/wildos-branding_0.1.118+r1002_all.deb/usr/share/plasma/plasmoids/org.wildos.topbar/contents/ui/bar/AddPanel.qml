pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Dialogs
import QtQuick.Effects
import QtQuick.Templates as T
import QtCore
import WildOS.UI as UI
import org.wildos.shell as WildOS
import "Defaults.js" as Defaults

// "Add to the left / the middle / the right" (board 4.17): 320 wide, 16px
// in, radius 12, rgba(28,30,38,0.96) with a 0.12 edge, a 13px semibold
// heading, the search field and the list of what can go on the bar.
// Battery is offered only with a battery and Cooler only with a supported
// cooler. Another clock and Weather ask a second question first (their
// Setup files), and A folder or file offers the usual folders or a
// chooser.
Item {
    id: panel

    // "left", "middle" or "right".
    property string region: "left"
    property bool hasBattery: false
    property bool hasCooler: false

    // Entries to put on the bar, in order.
    signal added(var entries)
    signal closed()

    // "list", "path" or a type with a Setup step.
    property string step: "list"
    property int current: 0

    readonly property var catalogue: [
        { type: "search", title: qsTr("Search"), subtitle: qsTr("Find apps, files and settings"), icon: Defaults.icons.search },
        { type: "path", title: qsTr("A folder or file"), subtitle: qsTr("Drop one on the bar, or choose it here"), icon: Defaults.icons.folder },
        { type: "clipboard", title: qsTr("Clipboard history"), subtitle: qsTr("The last things you copied"), icon: Defaults.icons.clipboard },
        { type: "capture", title: qsTr("Capture"), subtitle: qsTr("Screenshots and screen recording"), icon: Defaults.icons.capture },
        { type: "media", title: qsTr("Now playing"), subtitle: qsTr("What is playing, with controls"), icon: Defaults.icons.music },
        { type: "cpu", title: qsTr("Processor"), subtitle: qsTr("Use and temperature"), icon: Defaults.icons.cpu },
        { type: "memory", title: qsTr("Memory"), subtitle: qsTr("How much is in use"), icon: Defaults.icons.memory },
        { type: "gpu", title: qsTr("Graphics"), subtitle: qsTr("Use and temperature"), icon: Defaults.icons.gpu },
        { type: "network", title: qsTr("Network speed"), subtitle: qsTr("Download and upload right now"), icon: Defaults.icons.network },
        { type: "disk", title: qsTr("Disk"), subtitle: qsTr("Activity and free space"), icon: Defaults.icons.disk },
        { type: "battery", title: qsTr("Battery"), subtitle: qsTr("Charge and time left"), icon: Defaults.icons.battery },
        { type: "clock", title: qsTr("Another clock"), subtitle: qsTr("A city in a different time zone"), icon: Defaults.icons.clock },
        { type: "weather", title: qsTr("Weather"), subtitle: qsTr("Today where you are"), icon: Defaults.icons.weather },
        { type: "cooler", title: qsTr("Cooler"), subtitle: qsTr("Liquid temperature, pump and fans"), icon: Defaults.icons.cooler }
    ]

    readonly property var offered: {
        const q = field.text.trim().toLowerCase();
        return catalogue.filter(e => (e.type !== "battery" || hasBattery) && (e.type !== "cooler" || hasCooler)
            && (q.length === 0 || e.title.toLowerCase().indexOf(q) >= 0 || e.subtitle.toLowerCase().indexOf(q) >= 0));
    }
    onOfferedChanged: current = 0

    readonly property string heading: region === "middle" ? qsTr("Add to the middle")
        : region === "right" ? qsTr("Add to the right") : qsTr("Add to the left")

    implicitWidth: 320
    implicitHeight: card.height

    // Room left on the screen below the panel's top, set by the overlay so
    // the list scrolls rather than running off the screen.
    property real maximumHeight: 900

    function reset(): void {
        step = "list";
        field.text = "";
        current = 0;
        field.focusField();
    }

    function choose(entry: var): void {
        if (!entry) {
            return;
        }
        if (entry.type === "path") {
            step = "path";
        } else if (entry.type === "clock" || entry.type === "weather") {
            step = entry.type;
        } else {
            added([{ type: entry.type }]);
        }
    }

    function back(): void {
        step = "list";
        field.focusField();
    }

    Keys.onEscapePressed: step === "list" ? closed() : back()

    // The usual folders, for one click; only those that exist.
    readonly property string home: StandardPaths.writableLocation(StandardPaths.HomeLocation).toString().replace(/^file:\/\//, "")
    readonly property var folders: {
        const list = [
            { path: home, title: qsTr("Home") },
            { path: home + "/Projects", title: qsTr("Projects") },
            { path: StandardPaths.writableLocation(StandardPaths.DesktopLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Desktop") },
            { path: StandardPaths.writableLocation(StandardPaths.DocumentsLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Documents") },
            { path: StandardPaths.writableLocation(StandardPaths.DownloadLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Downloads") },
            { path: StandardPaths.writableLocation(StandardPaths.PicturesLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Pictures") },
            { path: StandardPaths.writableLocation(StandardPaths.MusicLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Music") },
            { path: StandardPaths.writableLocation(StandardPaths.MoviesLocation).toString().replace(/^file:\/\//, ""), title: qsTr("Videos") }
        ];
        return list.filter(f => f.path.length > 0 && WildOS.TopBarSettings.pathInfo(f.path).folder);
    }

    function addPath(url: var): void {
        const s = url.toString();
        const path = s.startsWith("file://") ? decodeURIComponent(s.slice(7)) : s;
        if (path.length > 0) {
            added([{ type: "path", path: path }]);
        }
    }

    FolderDialog {
        id: folderDialog
        title: qsTr("Choose a folder for the top bar")
        currentFolder: StandardPaths.writableLocation(StandardPaths.HomeLocation)
        onAccepted: panel.addPath(selectedFolder)
    }

    FileDialog {
        id: fileDialog
        title: qsTr("Choose a file for the top bar")
        currentFolder: StandardPaths.writableLocation(StandardPaths.DocumentsLocation)
        fileMode: FileDialog.OpenFile
        onAccepted: panel.addPath(selectedFile)
    }

    // 0 24px 60px rgba(0,0,0,0.5)
    MultiEffect {
        source: card
        anchors.fill: card
        shadowEnabled: true
        shadowColor: Qt.rgba(0, 0, 0, 0.5)
        shadowBlur: 1
        blurMax: 60
        shadowVerticalOffset: 24
        shadowHorizontalOffset: 0
    }

    Rectangle {
        id: card
        width: 320
        height: Math.min(panel.maximumHeight, content.implicitHeight + 32)
        radius: 12
        color: Qt.rgba(28 / 255, 30 / 255, 38 / 255, 0.96)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.12)

        Item {
            id: content
            x: 16
            y: 16
            width: 288
            height: card.height - 32
            implicitHeight: panel.step === "list" ? listColumn.implicitHeight
                : panel.step === "path" ? pathColumn.implicitHeight
                : setupLoader.item ? setupLoader.item.implicitHeight : 0

            // The list of everything that can go on the bar.
            Column {
                id: listColumn
                visible: panel.step === "list"
                width: parent.width
                spacing: 12

                UI.Label {
                    text: panel.heading
                    size: 13
                    color: "#ffffff"
                    font.weight: UI.Style.weightSemiBold
                }

                PanelField {
                    id: field
                    width: parent.width
                    placeholder: qsTr("Find something to add")
                    onAccepted: panel.choose(panel.offered[panel.current])
                    onDownPressed: {
                        panel.current = Math.min(panel.offered.length - 1, panel.current + 1);
                        list.positionViewAtIndex(panel.current, ListView.Contain);
                    }
                    onUpPressed: {
                        panel.current = Math.max(0, panel.current - 1);
                        list.positionViewAtIndex(panel.current, ListView.Contain);
                    }
                    onEscapePressed: panel.closed()
                }

                UI.Label {
                    visible: panel.offered.length === 0
                    width: parent.width
                    text: qsTr("Nothing by that name can go on the bar.")
                    wrapMode: Text.Wrap
                    size: 12.5
                    color: Qt.rgba(1, 1, 1, 0.68)
                }

                // margin: 0 -6px -6px
                ListView {
                    id: list
                    visible: panel.offered.length > 0
                    x: -6
                    width: parent.width + 12
                    height: Math.min(contentHeight + 6, panel.maximumHeight - 32 - 46 - 24)
                    bottomMargin: 6
                    clip: true
                    // The line icons are curve-rendered shapes, which the
                    // list's clip does not cut; drawing the list as one
                    // layer does.
                    layer.enabled: true
                    spacing: 2
                    boundsBehavior: Flickable.StopAtBounds
                    model: panel.offered

                    delegate: PanelRow {
                        required property var modelData
                        required property int index
                        width: ListView.view.width
                        icon: modelData.icon
                        title: modelData.title
                        subtitle: modelData.subtitle
                        current: index === panel.current && field.text.length > 0
                        onClicked: panel.choose(modelData)
                    }

                    T.ScrollBar.vertical: UI.ScrollBar {}
                }
            }

            // A folder or file: the usual folders, or choose any.
            Column {
                id: pathColumn
                visible: panel.step === "path"
                width: parent.width
                spacing: 12

                Heading {
                    text: qsTr("A folder or file")
                    onBack: panel.back()
                }

                Column {
                    x: -6
                    width: parent.width + 12
                    spacing: 2

                    Repeater {
                        model: panel.folders

                        PanelRow {
                            required property var modelData
                            width: parent.width
                            icon: Defaults.icons.folder
                            title: modelData.title
                            subtitle: modelData.path
                            onClicked: panel.added([{ type: "path", path: modelData.path }])
                        }
                    }

                    PanelRow {
                        width: parent.width
                        icon: Defaults.icons.folder
                        title: qsTr("Choose a folder")
                        subtitle: qsTr("Any folder on this PC or a drive")
                        onClicked: folderDialog.open()
                    }

                    PanelRow {
                        width: parent.width
                        icon: Defaults.icons.file
                        title: qsTr("Choose a file")
                        subtitle: qsTr("It opens in its usual app")
                        onClicked: fileDialog.open()
                    }
                }
            }

            // Another clock's and Weather's own second step.
            Loader {
                id: setupLoader
                width: parent.width
                active: panel.step === "clock" || panel.step === "weather"
                source: panel.step === "clock" ? "items/ClockSetup.qml" : panel.step === "weather" ? "items/WeatherSetup.qml" : ""
                onLoaded: item.width = Qt.binding(() => setupLoader.width)
                onStatusChanged: {
                    if (status === Loader.Error) {
                        panel.back();
                    }
                }

                Connections {
                    target: setupLoader.item
                    ignoreUnknownSignals: true
                    function onDone(config: var): void { panel.added([config]); }
                    function onCancelled(): void { panel.back(); }
                }
            }
        }
    }

    // A step's heading: back, then its name in 13px semibold.
    component Heading: Row {
        id: heading

        property string text
        signal back()

        spacing: 8

        Rectangle {
            width: 22
            height: 22
            radius: 6
            anchors.verticalCenter: parent.verticalCenter
            color: backMouse.pressed ? Qt.rgba(1, 1, 1, 0.13) : backMouse.containsMouse ? Qt.rgba(1, 1, 1, 0.09) : "transparent"
            Accessible.role: Accessible.Button
            Accessible.name: qsTr("Back")

            UI.Glyph {
                anchors.centerIn: parent
                width: 14
                height: 14
                path: Defaults.icons.back
                color: "#ffffff"
            }

            MouseArea {
                id: backMouse
                anchors.fill: parent
                hoverEnabled: true
                onClicked: heading.back()
            }
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            text: heading.text
            size: 13
            color: "#ffffff"
            font.weight: UI.Style.weightSemiBold
        }
    }
}
