import QtQuick
import org.kde.ksysguard.process as Process

// "Using the most": the app with the largest share of one resource, named
// as Task Manager's Apps list names it (libksysguard groups processes by
// the systemd scope each app is started in and names it from its launcher,
// the same source Task Manager uses). Only runs while a panel shows it.
Item {
    id: top

    property bool active: false
    // "cpu", "memory", "disk" or "gpu".
    property string metric: "cpu"
    // Task Manager divides libksysguard's per-process CPU by this.
    property int cpuCount: 1

    // { name, value }, or null before the first count and when no app runs.
    property var leader: null
    property bool counted: false
    // The row's text: "Files, 3%" through `describe`.
    function text(describe: var): string {
        if (!supported) {
            return qsTr("Not reported on this PC");
        }
        if (!counted) {
            return qsTr("Checking");
        }
        if (!leader) {
            return qsTr("No apps open");
        }
        // The row elides at its end, which would cut off the share.
        const name = leader.name.length > 22 ? leader.name.slice(0, 21).trim() + "…" : leader.name;
        return qsTr("%1, %2").arg(name).arg(describe(leader.value));
    }
    // Per-app graphics use exists only where libksysguard's NVIDIA plugin
    // found nvidia-smi; Task Manager's own reading of the kernel's figures
    // is not something QML can reach.
    readonly property bool supported: metric !== "gpu" || hasNvidia
    // Read once the model exists; asking for an attribute it lacks logs an
    // error on every start.
    property bool hasNvidia: false

    readonly property var attributes: metric === "cpu" ? ["appName", "usage"]
        : metric === "memory" ? ["appName", "memory"]
        : metric === "disk" ? ["appName", "ioCharactersActuallyReadRate", "ioCharactersActuallyWrittenRate"]
        : hasNvidia ? ["appName", "nvidia_usage"] : ["appName"]

    Process.ApplicationDataModel {
        id: model
        enabled: top.active && top.supported
        enabledAttributes: top.attributes
        onDataChanged: settle.restart()
        onRowsInserted: settle.restart()
        onRowsRemoved: settle.restart()
        onModelReset: settle.restart()
    }

    // The model changes cell by cell; one count once a round has landed.
    Timer {
        id: settle
        interval: 150
        onTriggered: top.count()
    }

    // With no app running the model never changes; a count once the first
    // round of numbers is in says so instead of "Checking" for ever.
    Timer {
        id: firstCount
        interval: 1500
        onTriggered: top.count()
    }

    Component.onCompleted: {
        hasNvidia = model.availableAttributes.indexOf("nvidia_usage") >= 0;
        activeChanged();
    }

    onActiveChanged: {
        if (active) {
            firstCount.restart();
        } else {
            firstCount.stop();
            settle.stop();
            leader = null;
            counted = false;
        }
    }

    function cell(row: int, column: int): real {
        const v = model.data(model.index(row, column), Qt.UserRole);
        const n = Number(v);
        return isNaN(n) ? 0 : n;
    }

    function count(): void {
        let best = null;
        for (let r = 0; r < model.rowCount(); ++r) {
            const name = String(model.data(model.index(r, 0), Qt.UserRole) || "");
            // A scope with no launcher behind it keeps its systemd unit name
            // (all lower case, like "dev-wildos-auto-theme"): a background
            // process, which Task Manager does not list as an app either.
            if (name.length === 0 || /^[a-z0-9_.@-]+$/.test(name)) {
                continue;
            }
            let value = 0;
            if (metric === "cpu") {
                value = cell(r, 1) / Math.max(1, cpuCount);
            } else if (metric === "memory") {
                value = cell(r, 1) * 1024;
            } else if (metric === "disk") {
                value = cell(r, 1) + cell(r, 2);
            } else {
                value = cell(r, 1);
            }
            if (!best || value > best.value) {
                best = { name: name, value: value };
            }
        }
        leader = best;
        counted = true;
    }
}
