import QtQuick
import WildOS.UI as UI
import ".."
import "../Defaults.js" as Defaults

// Search: the 26px square magnifier at the left end (22px in Compact). It
// opens Start ready to search, exactly as Win+S does.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property bool shown: true
    readonly property string accessibleName: qsTr("Search")

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    function activate(): void {
        if (!preview && host) {
            host.openSearch();
        }
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        fixedWidth: item.compact ? 22 : 26
        leftPadding: 0
        rightPadding: 0
        tip: qsTr("Search (Win+S)")
        onClicked: item.activate()

        UI.Glyph {
            width: 14
            height: 14
            path: Defaults.icons.search
            color: "#ffffff"
        }
    }
}
