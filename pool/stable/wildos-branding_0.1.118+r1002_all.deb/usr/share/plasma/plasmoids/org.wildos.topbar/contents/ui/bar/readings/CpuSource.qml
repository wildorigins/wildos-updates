import QtQuick
import org.kde.ksysguard.sensors as Sensors

// Processor readings from ksystemstats, the sensors Task Manager reads:
// use, average speed and average temperature of all cores. Subscribed only
// while the bar is live, at most one update a second.
Item {
    id: source

    property bool live: false

    readonly property bool ready: usage.status === Sensors.Sensor.Ready
    readonly property real percent: ready ? Number(usage.value) || 0 : 0
    readonly property real speed: Number(frequency.value) || 0
    // NaN without a temperature sensor ksystemstats knows.
    readonly property real temperature: temp.status === Sensors.Sensor.Ready && Number(temp.value) > 0 ? Number(temp.value) : NaN
    // Logical processors, what Task Manager divides each app's CPU by
    // (ksystemstats' cpuCount is the number of packages).
    readonly property int cpuCount: Math.max(1, Number(count.value) || 1)
    readonly property alias values: history.values

    Sensors.Sensor {
        id: usage
        sensorId: "cpu/all/usage"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: frequency
        sensorId: "cpu/all/averageFrequency"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: temp
        sensorId: "cpu/all/averageTemperature"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: count
        sensorId: "cpu/all/coreCount"
        enabled: source.live
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.percent : NaN
    }
}
