import QtQuick
import org.kde.ksysguard.sensors as Sensors

// Download and upload across every connection, in bytes a second, from
// ksystemstats (the Network speed sensors of Plasma's own widget).
Item {
    id: source

    property bool live: false

    readonly property bool ready: down.status === Sensors.Sensor.Ready
    readonly property real download: Number(down.value) || 0
    readonly property real upload: Number(up.value) || 0
    readonly property alias values: history.values
    readonly property alias uploads: upHistory.values

    Sensors.Sensor {
        id: down
        sensorId: "network/all/download"
        enabled: source.live
        updateRateLimit: 1000
    }
    Sensors.Sensor {
        id: up
        sensorId: "network/all/upload"
        enabled: source.live
        updateRateLimit: 1000
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.download : NaN
    }
    History {
        id: upHistory
        live: source.live
        sample: () => source.ready ? source.upload : NaN
    }
}
