import QtQuick
import WildOS.UI as UI

// Text on the bar: 12.5px Albert Sans, white. A value (`figures`) is 550
// weight with tabular figures so it does not jitter as it changes.
UI.Label {
    property bool figures: false

    anchors.verticalCenter: parent ? parent.verticalCenter : undefined
    size: 12.5
    color: "#ffffff"
    elide: Text.ElideNone
    font.weight: figures ? UI.Style.weightSemiBold : UI.Style.weightRegular
    font.features: figures ? { "tnum": 1 } : {}
}
