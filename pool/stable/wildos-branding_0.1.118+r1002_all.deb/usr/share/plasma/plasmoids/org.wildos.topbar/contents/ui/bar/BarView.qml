pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Effects
import QtQuick.Shapes
import WildOS.UI as UI
import "Defaults.js" as Defaults

// The whole top bar as boards 4.15 to 4.20 draw it: three regions, the
// middle one centred on the screen whatever the other two hold, items
// 24px tall (20 in Compact) with 1px between them and a divider wherever
// the kind of item changes. Upright on the left or right edge it shows
// icons only.
//
// It is drawn the same in the panel and in Settings' previews, which load
// this file by its path: nothing here may need the Plasma applet, and with
// `preview` on (and no host) nothing acts or starts.
FocusScope {
    id: bar

    property var layout: ({ left: [], middle: [], right: [] })
    // "standard" or "compact".
    property string size: "standard"
    // "top", "left" or "right".
    property string edge: "top"
    property bool vertical: edge === "left" || edge === "right"
    // "glass" or "clear".
    property string look: "glass"
    property bool live: false
    property bool preview: false
    property bool editing: false
    property var host: null
    // Where the screen's centre is along the bar. The panel spans the
    // screen, so by default it is the bar's own centre.
    property real centre: (vertical ? height : width) / 2
    // The region whose plus button opened the Add panel, drawn pressed.
    property string addingTo: ""

    readonly property bool overclock: UI.Theme.themeId === "overclock"
    readonly property color accent: overclock ? "#ff5a78" : UI.Theme.accent
    readonly property bool compact: size === "compact"
    readonly property int thickness: editing ? 42 : compact ? 24 : 32
    readonly property bool dragging: dragState.active

    // A new layout from editing: an item moved or dragged off the bar.
    signal edited(var layout)
    // A plus button was pressed; `anchor` is the button.
    signal addRequested(string region, Item anchor)
    // Folders or files dropped from Files, with where they landed.
    signal pathsDropped(var urls, string region, int index)
    // A right click on the bar. `region` and `index` say which item was
    // under the pointer, or region is "" for the bar itself.
    signal menuRequested(string region, int index, real x, real y)
    // Escape while the keyboard is on the bar.
    signal keyboardLeft()

    implicitWidth: vertical ? thickness : 800
    implicitHeight: vertical ? 600 : thickness

    readonly property var regionItems: [leftRegion, middleRegion, rightRegion]

    function regionNamed(name: string): Item {
        return name === "left" ? leftRegion : name === "middle" ? middleRegion : rightRegion;
    }

    function along(p: point): real {
        return vertical ? p.y : p.x;
    }

    function across(p: point): real {
        return vertical ? p.x : p.y;
    }

    // Glass

    Item {
        id: glass
        anchors.fill: parent
        visible: bar.look !== "clear"

        // CSS's 180deg gradient runs top to bottom; upright bars run it
        // from the screen edge inwards.
        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                orientation: bar.vertical ? Gradient.Horizontal : Gradient.Vertical
                GradientStop {
                    position: bar.edge === "right" ? 1 : 0
                    color: bar.overclock ? Qt.rgba(22 / 255, 14 / 255, 18 / 255, 0.86) : Qt.rgba(30 / 255, 32 / 255, 42 / 255, 0.80)
                }
                GradientStop {
                    position: bar.edge === "right" ? 0 : 1
                    color: bar.overclock ? Qt.rgba(12 / 255, 10 / 255, 14 / 255, 0.86) : Qt.rgba(17 / 255, 19 / 255, 26 / 255, 0.80)
                }
            }
        }

        // inset 0 1px 0 rgba(255,255,255,0.06): light along the outer edge.
        Rectangle {
            x: bar.edge === "right" ? parent.width - 1 : 0
            width: bar.vertical ? 1 : parent.width
            height: bar.vertical ? parent.height : 1
            color: Qt.rgba(1, 1, 1, bar.overclock ? 0.05 : 0.06)
        }

        // border-bottom: 1px rgba(255,255,255,0.07), on the side facing
        // the windows.
        Rectangle {
            id: innerEdge
            x: bar.edge === "left" ? parent.width - 1 : 0
            y: bar.vertical ? 0 : parent.height - 1
            width: bar.vertical ? 1 : parent.width
            height: bar.vertical ? parent.height : 1
            color: Qt.rgba(1, 1, 1, 0.07)
        }
    }

    // Overclock's glow line (board 4.20, 0 1px 0 rgba(255,60,90,0.50)),
    // kept in either look.
    Rectangle {
        visible: bar.overclock
        x: innerEdge.x
        y: innerEdge.y
        width: innerEdge.width
        height: innerEdge.height
        color: Qt.rgba(1, 60 / 255, 90 / 255, 0.50)
    }

    // Right clicks on the bar itself or on an item without a menu of its
    // own, and the press that takes the keyboard away from the bar.
    MouseArea {
        anchors.fill: parent
        enabled: !bar.preview
        acceptedButtons: Qt.RightButton
        onClicked: mouse => {
            const hit = bar.entryAt(Qt.point(mouse.x, mouse.y));
            bar.menuRequested(hit ? hit.region : "", hit ? hit.index : -1, mouse.x, mouse.y);
        }
    }

    // Everything drawn on the bar. With Clear there is no glass behind it,
    // so a soft shadow keeps white text readable on a light wallpaper.
    Item {
        id: content
        anchors.fill: parent
        layer.enabled: bar.look === "clear" && !bar.preview
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: Qt.rgba(0, 0, 0, 0.75)
            shadowBlur: 0.35
            shadowVerticalOffset: 1
            shadowHorizontalOffset: 0
        }

        Region {
            id: leftRegion
            view: bar
            name: "left"
            entries: bar.layout && bar.layout.left ? bar.layout.left : []
            align: "start"
            start: 6
            end: middleRegion.boxStart - 8
        }

        Region {
            id: middleRegion
            view: bar
            name: "middle"
            entries: bar.layout && bar.layout.middle ? bar.layout.middle : []
            align: "centre"
            readonly property real boxLength: contentLength + (bar.editing ? 11 : 0)
            start: Math.round(bar.centre - boxLength / 2)
            end: start + boxLength
        }

        Region {
            id: rightRegion
            view: bar
            name: "right"
            entries: bar.layout && bar.layout.right ? bar.layout.right : []
            align: "end"
            start: middleRegion.boxEnd + 8
            end: (bar.vertical ? bar.height : bar.width) - 6
        }
    }

    // The keyboard (Super+Alt+B): arrows move between items, Enter and
    // Space use the one with the ring, Escape gives the keyboard back.

    property int focusIndex: 0
    readonly property var navigable: {
        const out = [];
        for (const r of [leftRegion, middleRegion, rightRegion]) {
            r.revision;
            for (let i = 0; i < r.slots.count; i++) {
                const s = r.slots.itemAt(i);
                if (s && s.visible) {
                    out.push(s);
                }
            }
        }
        return out;
    }
    readonly property Item focusSlot: activeFocus && navigable.length > 0
        ? navigable[Math.max(0, Math.min(focusIndex, navigable.length - 1))] : null

    function moveFocus(step: int): void {
        if (navigable.length === 0) {
            return;
        }
        focusIndex = (Math.max(0, Math.min(focusIndex, navigable.length - 1)) + step + navigable.length) % navigable.length;
    }

    Keys.onPressed: event => {
        const back = vertical ? Qt.Key_Up : Qt.Key_Left;
        const forward = vertical ? Qt.Key_Down : Qt.Key_Right;
        if (event.key === back || (vertical && event.key === Qt.Key_Left) || (!vertical && event.key === Qt.Key_Up)) {
            moveFocus(-1);
        } else if (event.key === forward || (vertical && event.key === Qt.Key_Right) || (!vertical && event.key === Qt.Key_Down)) {
            moveFocus(1);
        } else if (event.key === Qt.Key_Home) {
            focusIndex = 0;
        } else if (event.key === Qt.Key_End) {
            focusIndex = navigable.length - 1;
        } else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter || event.key === Qt.Key_Space) {
            if (focusSlot && !editing) {
                focusSlot.barItem.activate();
            }
        } else if (event.key === Qt.Key_Menu && focusSlot) {
            const p = focusSlot.mapToItem(bar, focusSlot.width / 2, focusSlot.height / 2);
            menuRequested(focusSlot.owner.name, focusSlot.index, p.x, p.y);
        } else if (event.key === Qt.Key_Escape) {
            keyboardLeft();
        } else {
            return;
        }
        event.accepted = true;
    }
    onActiveFocusChanged: {
        if (activeFocus) {
            focusIndex = 0;
        }
    }

    // .wos-btn:focus-visible: 2px #8fb4ff outline, 2px outside the item.
    Rectangle {
        visible: bar.focusSlot !== null
        readonly property rect box: bar.focusSlot ? bar.focusSlot.itemRect(bar) : Qt.rect(0, 0, 0, 0)
        x: box.x - 4
        y: box.y - 4
        width: box.width + 8
        height: box.height + 8
        radius: 10
        color: "transparent"
        border.width: 2
        border.color: bar.accent
    }

    // Dragging in edit mode and drops from Files

    QtObject {
        id: dragState
        property bool active: false
        property string region: ""
        property int index: -1
        property Item slot: null
        property point pos: Qt.point(0, 0)
        property point grab: Qt.point(0, 0)
        // Where it would land, or region "" to remove it.
        property var target: null
    }

    // How far off the bar the pointer may stray and still drop on it.
    readonly property real dropTolerance: 10

    function onBar(p: point): bool {
        const a = across(p);
        const l = along(p);
        return a >= -dropTolerance && a <= thickness + dropTolerance && l >= 0 && l <= (vertical ? height : width);
    }

    // The region and insertion index for a point on the bar.
    function dropTargetAt(p: point): var {
        if (!onBar(p)) {
            return null;
        }
        const l = along(p);
        const midStart = middleRegion.boxStart;
        const midEnd = middleRegion.boxEnd;
        // An empty middle still takes drops near the centre.
        const pad = Math.max(0, 28 - (midEnd - midStart) / 2);
        let r = rightRegion;
        if (l < midStart - pad) {
            r = leftRegion;
        } else if (l <= midEnd + pad) {
            r = middleRegion;
        }
        return { region: r.name, index: r.insertionIndex(r.mapFromItem(bar, p.x, p.y)) };
    }

    function slotAt(region: string, index: int): Item {
        const r = regionNamed(region);
        return index >= 0 && index < r.slots.count ? r.slots.itemAt(index) : null;
    }

    // Where an item (an items/<Type>Item.qml) sits in the layout.
    function locate(item: Item): var {
        for (const r of [leftRegion, middleRegion, rightRegion]) {
            for (let i = 0; i < r.slots.count; i++) {
                const s = r.slots.itemAt(i);
                if (s && s.barItem.item === item) {
                    return { region: r.name, index: i };
                }
            }
        }
        return null;
    }

    // The entry under a point, for right clicks.
    function entryAt(p: point): var {
        for (const r of [leftRegion, middleRegion, rightRegion]) {
            for (let i = 0; i < r.slots.count; i++) {
                const s = r.slots.itemAt(i);
                if (s && s.visible) {
                    const q = s.mapFromItem(bar, p.x, p.y);
                    if (q.x >= 0 && q.y >= 0 && q.x < s.width && q.y < s.height) {
                        return { region: r.name, index: i };
                    }
                }
            }
        }
        return null;
    }

    function startDrag(region: string, index: int, slot: Item, p: point): void {
        dragState.region = region;
        dragState.index = index;
        dragState.slot = slot;
        const r = slot.itemRect(bar);
        dragState.grab = Qt.point(p.x - r.x, p.y - r.y);
        dragState.pos = p;
        dragState.target = { region: region, index: index };
        dragState.active = true;
    }

    function cancelDrag(): void {
        dragState.active = false;
        dragState.slot = null;
        dragState.target = null;
    }

    function moveDrag(p: point): void {
        dragState.pos = p;
        dragState.target = dropTargetAt(p);
    }

    function endDrag(p: point): void {
        if (!dragState.active) {
            return;
        }
        const t = dropTargetAt(p);
        const from = dragState.region;
        const index = dragState.index;
        dragState.active = false;
        dragState.slot = null;
        dragState.target = null;
        if (!t) {
            edited(Defaults.removed(layout, from, index));
        } else if (t.region !== from || (t.index !== index && t.index !== index + 1)) {
            edited(Defaults.moved(layout, from, index, t.region, t.index));
        }
    }

    // The item under the pointer while it is dragged. Off the bar it fades
    // to say letting go removes it.
    ShaderEffectSource {
        id: ghost
        visible: dragState.active && dragState.slot !== null
        sourceItem: dragState.active && dragState.slot ? dragState.slot.barItem : null
        hideSource: visible
        live: true
        readonly property rect from: dragState.slot ? dragState.slot.itemRect(bar) : Qt.rect(0, 0, 0, 0)
        width: from.width
        height: from.height
        x: bar.vertical ? from.x : dragState.pos.x - dragState.grab.x
        y: bar.vertical ? dragState.pos.y - dragState.grab.y : from.y
        opacity: dragState.target ? 0.9 : 0.35
        z: 10
    }

    // Where a dragged item or a dropped folder will go.
    Rectangle {
        id: marker
        property var target: dragState.active ? dragState.target : drop.target
        visible: target !== null && target !== undefined
        readonly property real at: visible ? bar.regionNamed(target.region).insertionPoint(target.index) : 0
        x: bar.vertical ? (bar.thickness - width) / 2 : at - 1
        y: bar.vertical ? at - 1 : (bar.thickness - height) / 2
        width: bar.vertical ? (bar.compact ? 20 : 24) : 2
        height: bar.vertical ? 2 : (bar.compact ? 20 : 24)
        radius: 1
        color: bar.accent
        z: 9
    }

    DropArea {
        id: drop
        anchors.fill: parent
        enabled: !bar.preview
        keys: ["text/uri-list"]
        property var target: null
        onEntered: dragEvent => {
            dragEvent.accepted = dragEvent.hasUrls;
            target = dragEvent.hasUrls ? bar.dropTargetAt(Qt.point(dragEvent.x, dragEvent.y)) : null;
        }
        onPositionChanged: dragEvent => target = bar.dropTargetAt(Qt.point(dragEvent.x, dragEvent.y))
        onExited: target = null
        onDropped: dropEvent => {
            const t = target || bar.dropTargetAt(Qt.point(dropEvent.x, dropEvent.y)) || { region: "left", index: -1 };
            target = null;
            const urls = [];
            for (const u of dropEvent.urls) {
                const s = u.toString();
                if (s.startsWith("file://")) {
                    urls.push(s);
                }
            }
            if (urls.length > 0) {
                dropEvent.acceptProposedAction();
                bar.pathsDropped(urls, t.region, t.index);
            }
        }
    }

    // A region: its items in order, the dashed outline and plus button
    // while editing, dividers between groups, and items that no longer fit
    // hidden from the end nearest the middle.
    component Region: Item {
        id: region

        // The BarView: an inline component cannot see the ids of the file
        // it is declared in.
        property var view
        property string name
        property var entries: []
        // "start", "centre" or "end": which end the items keep to.
        property string align: "start"
        // The region's box along the bar, in bar coordinates.
        property real start: 0
        property real end: 0
        readonly property real boxStart: start
        readonly property real boxEnd: Math.max(start, end)

        readonly property alias slots: repeater
        property int revision: 0
        // Length of the items, dividers and plus button with their 1px gaps.
        property real contentLength: 0
        property var positions: []

        readonly property real pad: region.view.editing ? 5.5 : 0
        readonly property real plusLength: region.view.editing ? 23 : 0

        x: region.view.vertical ? 0 : boxStart
        y: region.view.vertical ? boxStart : 0
        width: region.view.vertical ? region.view.thickness : boxEnd - boxStart
        height: region.view.vertical ? boxEnd - boxStart : region.view.thickness

        function relayoutSoon(): void {
            relayoutTimer.restart();
        }

        Timer {
            id: relayoutTimer
            interval: 0
            onTriggered: region.relayout()
        }

        onEntriesChanged: relayoutSoon()
        onWidthChanged: relayoutSoon()
        onHeightChanged: relayoutSoon()
        Connections {
            target: region.view
            function onEditingChanged() { region.relayoutSoon(); }
            function onVerticalChanged() { region.relayoutSoon(); }
            function onCompactChanged() { region.relayoutSoon(); }
        }

        function lengthOf(s: Item): real {
            return region.view.vertical ? s.barItem.implicitHeight : s.barItem.implicitWidth;
        }

        // Which items show, where the dividers go and where each one sits.
        function relayout(): void {
            const n = repeater.count;
            const wanted = [];
            for (let i = 0; i < n; i++) {
                const s = repeater.itemAt(i);
                wanted.push(s !== null && s.wanted);
            }
            const room = (region.view.vertical ? height : width) - 2 * pad - plusLength;
            // Items fit from the outer end of the region inwards.
            const order = [];
            for (let i = 0; i < n; i++) {
                order.push(align === "end" ? n - 1 - i : i);
            }
            const fits = new Array(n).fill(false);
            let used = 0;
            let lastGroup = null;
            let full = false;
            for (const i of order) {
                if (!wanted[i]) {
                    continue;
                }
                const s = repeater.itemAt(i);
                let need = lengthOf(s) + (used > 0 ? 1 : 0);
                if (lastGroup !== null && lastGroup !== s.barItem.group) {
                    need += 12;
                }
                if (full || (align !== "centre" && used + need > room + 0.5)) {
                    full = true;
                    continue;
                }
                fits[i] = true;
                used += need;
                lastGroup = s.barItem.group;
            }
            // Dividers between shown neighbours of different groups, and
            // positions from the region's start.
            const dividers = new Array(n).fill(false);
            const pos = new Array(n).fill(0);
            let cursor = pad + (region.view.editing && align === "end" ? plusLength : 0);
            let prev = null;
            for (let i = 0; i < n; i++) {
                if (!fits[i]) {
                    continue;
                }
                const s = repeater.itemAt(i);
                if (prev !== null) {
                    cursor += 1;
                    if (prev.barItem.group !== s.barItem.group) {
                        dividers[i] = true;
                        cursor += 12;
                    }
                }
                pos[i] = cursor;
                cursor += lengthOf(s);
                prev = s;
            }
            const itemsLength = cursor - pad - (region.view.editing && align === "end" ? plusLength : 0);
            const total = itemsLength + plusLength;
            contentLength = total;
            // Right-hand items keep to the far end of the region.
            const shift = align === "end" ? Math.max(0, (region.view.vertical ? height : width) - 2 * pad - total) : 0;
            for (let i = 0; i < n; i++) {
                const s = repeater.itemAt(i);
                if (s) {
                    s.fits = fits[i];
                    s.dividerBefore = dividers[i];
                    s.place = pos[i] + shift;
                }
            }
            positions = pos.map(v => v + shift);
            plusOffset = align === "end" ? pad + shift : pad + itemsLength + (itemsLength > 0 ? 1 : 0);
            revision++;
        }

        property real plusOffset: 0

        // Index to insert at for a point in region coordinates: before the
        // first shown item whose middle is past the point.
        function insertionIndex(p: point): int {
            const l = region.view.vertical ? p.y : p.x;
            for (let i = 0; i < repeater.count; i++) {
                const s = repeater.itemAt(i);
                if (s && s.visible && l < s.place + lengthOf(s) / 2) {
                    return i;
                }
            }
            return repeater.count;
        }

        // Where the insertion marker goes for an index, in bar coordinates.
        function insertionPoint(index: int): real {
            const base = region.view.vertical ? y : x;
            for (let i = index; i < repeater.count; i++) {
                const s = repeater.itemAt(i);
                if (s && s.visible) {
                    return base + s.place - 1;
                }
            }
            for (let i = Math.min(index, repeater.count) - 1; i >= 0; i--) {
                const s = repeater.itemAt(i);
                if (s && s.visible) {
                    return base + s.place + lengthOf(s) + 1;
                }
            }
            return base + (align === "end" ? (region.view.vertical ? height : width) - pad : align === "centre" ? (region.view.vertical ? height : width) / 2 : pad);
        }

        // board 4.17: 1.5px dashed rgba(143,180,255,0.75) on a 0.08 fill,
        // radius 8, 2px by 4px inside.
        Shape {
            id: outline
            visible: region.view.editing
            readonly property real inset: 0.75
            readonly property real boxAcross: (region.view.compact ? 20 : 24) + 7
            x: region.view.vertical ? (region.view.thickness - boxAcross) / 2 : 0
            y: region.view.vertical ? 0 : (region.view.thickness - boxAcross) / 2
            width: region.view.vertical ? boxAcross : region.width
            height: region.view.vertical ? region.height : boxAcross
            preferredRendererType: Shape.CurveRenderer

            ShapePath {
                strokeColor: Qt.rgba(region.view.accent.r, region.view.accent.g, region.view.accent.b, 0.75)
                strokeWidth: 1.5
                strokeStyle: ShapePath.DashLine
                dashPattern: [3, 2]
                fillColor: Qt.rgba(region.view.accent.r, region.view.accent.g, region.view.accent.b, 0.08)
                PathRectangle {
                    x: outline.inset
                    y: outline.inset
                    width: Math.max(0, outline.width - 2 * outline.inset)
                    height: Math.max(0, outline.height - 2 * outline.inset)
                    radius: 8
                }
            }
        }

        Repeater {
            id: repeater
            model: region.entries

            delegate: Item {
                id: slot

                required property var modelData
                required property int index
                property bool fits: true
                property bool dividerBefore: false
                property real place: 0
                readonly property BarItem barItem: item
                readonly property Item owner: region
                // Shown, or kept while editing so it can be moved or removed.
                readonly property bool wanted: item.shown || (region.view.editing && item.implicitWidth > 0)

                visible: wanted && fits
                x: region.view.vertical ? (region.view.thickness - width) / 2 : place - (dividerBefore ? 12 : 0)
                y: region.view.vertical ? place - (dividerBefore ? 12 : 0) : (region.view.thickness - height) / 2
                width: region.view.vertical ? item.implicitWidth : item.implicitWidth + (dividerBefore ? 12 : 0)
                height: region.view.vertical ? item.implicitHeight + (dividerBefore ? 12 : 0) : item.implicitHeight

                Accessible.role: Accessible.Button
                Accessible.name: item.accessibleName

                onWantedChanged: region.relayoutSoon()
                Connections {
                    target: item
                    function onImplicitWidthChanged() { region.relayoutSoon(); }
                    function onImplicitHeightChanged() { region.relayoutSoon(); }
                    function onGroupChanged() { region.relayoutSoon(); }
                }

                // The item's own box, without the divider before it.
                function itemRect(to: Item): rect {
                    const p = item.mapToItem(to, 0, 0);
                    return Qt.rect(p.x, p.y, item.width, item.height);
                }

                // 1x12, margin 0 5px, rgba(255,255,255,0.13).
                Rectangle {
                    visible: slot.dividerBefore
                    x: region.view.vertical ? (slot.width - 12) / 2 : 5
                    y: region.view.vertical ? 5 : (slot.height - 12) / 2
                    width: region.view.vertical ? 12 : 1
                    height: region.view.vertical ? 1 : 12
                    color: Qt.rgba(1, 1, 1, 0.13)
                }

                BarItem {
                    id: item
                    x: region.view.vertical ? 0 : (slot.dividerBefore ? 12 : 0)
                    y: region.view.vertical ? (slot.dividerBefore ? 12 : 0) : 0
                    width: implicitWidth
                    height: implicitHeight
                    config: slot.modelData
                    compact: region.view.compact
                    vertical: region.view.vertical
                    live: region.view.live && !region.view.preview
                    preview: region.view.preview
                    editing: region.view.editing
                    host: region.view.host
                    accent: region.view.accent
                    overclock: region.view.overclock
                    enabled: !region.view.editing
                }

                // While editing, items are picked up rather than used.
                MouseArea {
                    anchors.fill: item
                    enabled: region.view.editing && !region.view.preview
                    visible: enabled
                    preventStealing: true
                    cursorShape: region.view.dragging ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                    property point pressPoint
                    property bool moved: false
                    onPressed: mouse => {
                        pressPoint = mapToItem(region.view, mouse.x, mouse.y);
                        moved = false;
                    }
                    onPositionChanged: mouse => {
                        const p = mapToItem(region.view, mouse.x, mouse.y);
                        if (!moved && Math.abs(p.x - pressPoint.x) + Math.abs(p.y - pressPoint.y) > 4) {
                            moved = true;
                            region.view.startDrag(region.name, slot.index, slot, pressPoint);
                        }
                        if (moved) {
                            region.view.moveDrag(p);
                        }
                    }
                    onReleased: mouse => {
                        if (moved) {
                            region.view.endDrag(mapToItem(region.view, mouse.x, mouse.y));
                        }
                        moved = false;
                    }
                    onCanceled: {
                        if (moved) {
                            region.view.cancelDrag();
                        }
                        moved = false;
                    }
                }
            }
        }

        // The plus button: 22px, radius 6, the accent with a dark plus.
        Rectangle {
            id: plus
            visible: region.view.editing
            width: 22
            height: 22
            radius: 6
            x: region.view.vertical ? (region.view.thickness - width) / 2 : region.plusOffset
            y: region.view.vertical ? region.plusOffset : (region.view.thickness - height) / 2
            color: plusMouse.pressed || region.view.addingTo === region.name ? Qt.darker(region.view.accent, 1.08)
                : plusMouse.containsMouse ? Qt.lighter(region.view.accent, 1.08) : region.view.accent
            Accessible.role: Accessible.Button
            Accessible.name: qsTr("Add something here")

            UI.Glyph {
                anchors.centerIn: parent
                width: 14
                height: 14
                path: Defaults.icons.plus
                color: "#10131c"
            }

            MouseArea {
                id: plusMouse
                anchors.fill: parent
                enabled: !region.view.preview
                hoverEnabled: true
                onClicked: region.view.addRequested(region.name, plus)
            }

            UI.Tooltip {
                ownWindow: true
                visible: plusMouse.containsMouse && !plusMouse.pressed && region.view.addingTo !== region.name
                text: region.name === "left" ? qsTr("Add to the left") : region.name === "middle" ? qsTr("Add to the middle") : qsTr("Add to the right")
            }
        }
    }
}
