.pragma library

// Numbers as Windows Task Manager writes them: binary units under their
// usual names (1 GB is 1024 MB), one decimal for sizes and rates, whole
// numbers for per cents and temperatures, the regional separators.

function fixed(value, decimals) {
    return Number(value).toLocaleString(Qt.locale(), "f", decimals);
}

function whole(value) {
    return Number(Math.round(value)).toLocaleString(Qt.locale(), "f", 0);
}

function percent(value) {
    return qsTr("%1%").arg(Math.round(Math.max(0, value)));
}

// The board's "46°": no letter after the sign, as on the taskbar weather.
function degrees(value) {
    return qsTr("%1°").arg(Math.round(value));
}

function gigabytes(bytes) {
    return qsTr("%1 GB").arg(fixed(bytes / 1073741824, 1));
}

// Free space and totals: gigabytes, terabytes past a thousand.
function capacity(bytes) {
    if (bytes >= 1099511627776 * 0.98) {
        return qsTr("%1 TB").arg(fixed(bytes / 1099511627776, 1));
    }
    if (bytes >= 10737418240) {
        return qsTr("%1 GB").arg(whole(bytes / 1073741824));
    }
    return gigabytes(bytes);
}

function memory(bytes) {
    if (bytes < 1073741824) {
        return qsTr("%1 MB").arg(whole(bytes / 1048576));
    }
    return gigabytes(bytes);
}

function gigahertz(megahertz) {
    return qsTr("%1 GHz").arg(fixed(megahertz / 1000, 1));
}

function megahertz(value) {
    return qsTr("%1 MHz").arg(whole(value));
}

function rpm(value) {
    return qsTr("%1 RPM").arg(whole(value));
}

// One unit for a pair of rates, picked by the larger, so the bar reads
// "↓ 2.4 ↑ 0.3 MB/s" with the unit written once. Kilobytes below 0.1 MB/s.
function rateUnit(bytesPerSecond) {
    const mb = bytesPerSecond / 1048576;
    if (mb >= 1000) {
        return { divisor: 1073741824, unit: qsTr("GB/s") };
    }
    if (mb >= 0.1) {
        return { divisor: 1048576, unit: qsTr("MB/s") };
    }
    return { divisor: 1024, unit: qsTr("KB/s") };
}

function rateNumber(bytesPerSecond, unit) {
    const value = bytesPerSecond / unit.divisor;
    return value === 0 ? "0" : fixed(value, 1);
}

function rate(bytesPerSecond) {
    const unit = rateUnit(bytesPerSecond);
    return qsTr("%1 %2").arg(rateNumber(bytesPerSecond, unit)).arg(unit.unit);
}

// Battery time as the quick settings write it: "About 2 hours 10 minutes".
function duration(msec) {
    const minutes = Math.max(1, Math.round(msec / 60000));
    if (minutes < 60) {
        return minutes === 1 ? qsTr("1 minute") : qsTr("%1 minutes").arg(minutes);
    }
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    const h = hours === 1 ? qsTr("1 hour") : qsTr("%1 hours").arg(hours);
    if (rest === 0) {
        return h;
    }
    return qsTr("%1 %2").arg(h).arg(rest === 1 ? qsTr("1 minute") : qsTr("%1 minutes").arg(rest));
}

// The bar's short form of the same, "2 h 10 min".
function shortDuration(msec) {
    const minutes = Math.max(1, Math.round(msec / 60000));
    if (minutes < 60) {
        return qsTr("%1 min").arg(minutes);
    }
    const rest = minutes % 60;
    return rest === 0 ? qsTr("%1 h").arg(Math.floor(minutes / 60))
        : qsTr("%1 h %2 min").arg(Math.floor(minutes / 60)).arg(rest);
}
