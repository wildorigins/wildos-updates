import QtQuick
import QtQuick.Shapes

// The boards' reading ring: 14 by 14, radius 5.4, a 2px track at
// rgba(255,255,255,0.17) and the value in the accent from 12 o'clock
// clockwise with round ends (TopBar.dc, the stroke-dasharray circles).
Item {
    id: ring

    // 0 to 1.
    property real value: 0
    property color color: "#8fb4ff"
    property color trackColor: Qt.rgba(1, 1, 1, 0.17)

    readonly property real clamped: Math.max(0, Math.min(1, value))

    implicitWidth: 14
    implicitHeight: 14

    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer

        ShapePath {
            strokeColor: ring.trackColor
            strokeWidth: 2
            fillColor: "transparent"
            PathAngleArc {
                centerX: 7
                centerY: 7
                radiusX: 5.4
                radiusY: 5.4
                startAngle: 0
                sweepAngle: 360
            }
        }
    }

    // Nothing is drawn for zero: SVG's round caps on an empty dash would
    // leave a dot, the board never shows one.
    Shape {
        anchors.fill: parent
        visible: ring.clamped > 0.001
        preferredRendererType: Shape.CurveRenderer

        ShapePath {
            strokeColor: ring.color
            strokeWidth: 2
            fillColor: "transparent"
            capStyle: ring.clamped >= 1 ? ShapePath.FlatCap : ShapePath.RoundCap
            PathAngleArc {
                centerX: 7
                centerY: 7
                radiusX: 5.4
                radiusY: 5.4
                startAngle: -90
                sweepAngle: 360 * ring.clamped
            }
        }
    }
}
