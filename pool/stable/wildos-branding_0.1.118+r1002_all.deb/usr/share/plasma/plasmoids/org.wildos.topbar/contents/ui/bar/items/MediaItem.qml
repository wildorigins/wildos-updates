pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Effects
import QtQuick.Shapes
import WildOS.UI as UI
import ".."
import "../Defaults.js" as Defaults

// Now playing (board 4.15): the cover at 18px with radius 4, the track in
// 550 weight, who it is by muted, then previous, play or pause, and next.
// Compact keeps the 14px cover and the controls; upright, only the cover,
// which plays and pauses. It follows the player Plasma treats as the
// current one, the one the media keys control, and is not on the bar while
// nothing is open that plays. Edit mode draws the track without the artist
// (board 4.17).
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property bool editing: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property var current: players.item ? players.item.current : null
    readonly property bool playing: preview || (players.item !== null && players.item.playing)
    readonly property bool active: players.item !== null && players.item.active

    readonly property string title: preview ? "Low tide"
        : current && current.track.length > 0 ? current.track
        : active ? qsTr("Untitled") : qsTr("Now playing")
    readonly property string artist: preview ? "North Field"
        : current ? (current.artist || current.identity || "") : ""
    readonly property string art: preview || !current ? "" : (current.artUrl || "")

    readonly property bool shown: preview || active || editing
    readonly property string accessibleName: artist.length > 0 ? qsTr("Now playing: %1 by %2").arg(title).arg(artist)
        : qsTr("Now playing: %1").arg(title)

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight

    // The keyboard plays and pauses; a click on the track brings the player
    // forward, as Windows' media flyout does.
    function activate(): void {
        if (!preview && current && current.canControl) {
            current.container.PlayPause();
        }
    }

    function raise(): void {
        if (preview || !current) {
            return;
        }
        if (current.canRaise) {
            current.container.Raise();
        } else {
            activate();
        }
    }

    Loader {
        id: players
        active: !item.preview
        source: "MediaSource.qml"
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        leftPadding: 5
        rightPadding: 2
        tip: item.vertical || item.compact ? item.accessibleName : ""
        onClicked: item.vertical ? item.activate() : item.raise()

        // The cover, or the board's colour sweep where there is none.
        Item {
            anchors.verticalCenter: parent.verticalCenter
            width: item.compact ? 14 : 18
            height: width

            Shape {
                anchors.fill: parent
                visible: cover.status !== Image.Ready
                preferredRendererType: Shape.CurveRenderer
                layer.enabled: true
                layer.samples: 4

                ShapePath {
                    strokeColor: "transparent"
                    fillGradient: ConicalGradient {
                        centerX: (item.compact ? 14 : 18) * 0.4
                        centerY: (item.compact ? 14 : 18) * 0.6
                        angle: -120
                        GradientStop { position: 0; color: "#ff8a6b" }
                        GradientStop { position: 0.333; color: "#39c6e8" }
                        GradientStop { position: 0.667; color: "#7b5cff" }
                        GradientStop { position: 1; color: "#ff8a6b" }
                    }
                    PathRectangle {
                        width: item.compact ? 14 : 18
                        height: width
                        radius: 4
                    }
                }
            }

            Image {
                id: cover
                anchors.fill: parent
                visible: false
                asynchronous: true
                fillMode: Image.PreserveAspectCrop
                source: item.art
                sourceSize: Qt.size(48, 48)
                layer.enabled: true
            }

            Item {
                id: coverMask
                anchors.fill: parent
                visible: false
                layer.enabled: true

                Rectangle {
                    anchors.fill: parent
                    radius: 4
                }
            }

            MultiEffect {
                anchors.fill: parent
                visible: cover.status === Image.Ready
                source: cover
                maskEnabled: true
                maskSource: coverMask
            }

            // box-shadow: 0 0 0 1px rgba(255,255,255,0.10)
            Rectangle {
                anchors.fill: parent
                anchors.margins: -1
                radius: 5
                color: "transparent"
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.10)
            }
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical
            width: Math.min(implicitWidth, 220)
            text: item.title
            size: button.textSize
            color: button.ink
            font.weight: UI.Style.weightSemiBold
        }

        UI.Label {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.compact && !item.vertical && !item.editing && item.artist.length > 0
            width: Math.min(implicitWidth, 160)
            text: item.artist
            size: button.textSize
            color: button.inkMuted
        }

        Row {
            anchors.verticalCenter: parent.verticalCenter
            visible: !item.vertical
            leftPadding: 2

            Control {
                compact: item.compact
                interactive: !item.preview && !item.editing && item.current !== null
                name: "previous"
                label: qsTr("Previous")
                available: item.preview || item.editing || (item.current !== null && item.current.canGoPrevious)
                strong: false
                onTriggered: item.current.container.Previous()
            }

            Control {
                compact: item.compact
                interactive: !item.preview && !item.editing && item.current !== null
                name: item.playing ? "pause" : "play"
                label: item.playing ? qsTr("Pause") : qsTr("Play")
                available: item.preview || item.editing || (item.current !== null && item.current.canControl)
                strong: true
                onTriggered: item.current.container.PlayPause()
            }

            Control {
                compact: item.compact
                interactive: !item.preview && !item.editing && item.current !== null
                name: "next"
                label: qsTr("Next")
                available: item.preview || item.editing || (item.current !== null && item.current.canGoNext)
                strong: false
                onTriggered: item.current.container.Next()
            }
        }
    }

    // 22px wide (18px tall in Compact), radius 5, 13px icons: previous and
    // next at 0.62, play or pause at full white.
    component Control: Item {
        id: control

        property string name
        property string label
        property bool strong: false
        property bool compact: false
        property bool interactive: true
        // Whether the player offers it; drawn faint when it does not.
        property bool available: true
        signal triggered()

        width: 22
        height: compact ? 18 : 22
        Accessible.role: Accessible.Button
        Accessible.name: label

        Rectangle {
            anchors.fill: parent
            radius: 5
            color: area.pressed ? Qt.rgba(1, 1, 1, 0.13) : area.containsMouse ? Qt.rgba(1, 1, 1, 0.09) : "transparent"
        }

        UI.Glyph {
            anchors.centerIn: parent
            width: 13
            height: 13
            path: Defaults.icons[control.name]
            color: Qt.rgba(1, 1, 1, !control.available ? 0.3 : control.strong ? 1 : 0.62)
        }

        MouseArea {
            id: area
            anchors.fill: parent
            enabled: control.available && control.interactive
            hoverEnabled: true
            onClicked: control.triggered()
        }

        UI.Tooltip {
            ownWindow: true
            visible: area.containsMouse && !area.pressed
            text: control.label
        }
    }
}
