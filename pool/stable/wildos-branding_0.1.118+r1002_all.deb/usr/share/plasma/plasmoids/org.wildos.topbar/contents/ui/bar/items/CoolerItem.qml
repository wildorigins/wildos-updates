pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Cooler as board 4.20 draws it: two readings side by side, the liquid
// ("Liquid 34°" by a droplet) and the graphics card ("Graphics 61°" by a
// thermometer), 13px icons at rgba(255,255,255,0.7). Either opens the
// cooler's panel: the liquid's last minute, pump and fans. Shown only while
// a supported cooler is connected; the graphics reading only where the card
// reports a temperature.
Item {
    id: cooler

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    readonly property var src: loader.item
    readonly property bool shown: preview || (src !== null && src.present)
    readonly property real liquid: preview ? 34 : src ? src.liquid : NaN
    readonly property real gpuTemperature: preview ? 61 : src ? src.gpuTemperature : NaN
    property string accessibleName: isNaN(gpuTemperature)
        ? qsTr("Liquid %1 degrees").arg(Math.round(liquid))
        : qsTr("Liquid %1 degrees, graphics %2 degrees").arg(Math.round(liquid)).arg(Math.round(gpuTemperature))

    implicitWidth: row.implicitWidth
    implicitHeight: row.implicitHeight
    visible: shown

    function activate(): void {
        liquidItem.activate();
    }

    function openCooler(): void {
        if (!host) {
            return;
        }
        host.closePopup();
        host.launch("org.wildos.cooler.desktop");
    }

    // The liquid graph keeps the usual 20 to 50 degrees in view and grows
    // past it on a hot minute.
    readonly property real graphMaximum: {
        const list = src ? src.values : [];
        let top = 50;
        for (let i = 0; i < list.length; ++i) {
            top = Math.max(top, list[i] + 3);
        }
        return top;
    }

    readonly property var rows: {
        if (preview || !src) {
            return [
                { label: qsTr("Pump"), value: qsTr("%1 (%2)").arg(Format.rpm(2100)).arg(Format.percent(60)) },
                { label: qsTr("Fans"), value: qsTr("%1 (%2)").arg(Format.rpm(1200)).arg(Format.percent(40)) },
                { label: qsTr("Graphics"), value: Format.degrees(61) }
            ];
        }
        const list = [];
        list.push({ label: qsTr("Pump"), value: qsTr("%1 (%2)").arg(Format.rpm(src.pumpRpm)).arg(Format.percent(src.pumpDuty)) });
        if (src.fansOnCooler) {
            list.push({ label: qsTr("Fans"), value: qsTr("%1 (%2)").arg(Format.rpm(src.fanRpm)).arg(Format.percent(src.fanDuty)) });
        }
        if (!isNaN(gpuTemperature)) {
            list.push({ label: qsTr("Graphics"), value: Format.degrees(gpuTemperature) });
        }
        return list;
    }

    Loader {
        id: loader
        active: !cooler.preview
        source: "../readings/CoolerSource.qml"
        onLoaded: item.live = Qt.binding(() => cooler.live)
    }

    Component {
        id: coolerPanel
        ReadingPanel {
            title: qsTr("Liquid")
            value: isNaN(cooler.liquid) ? "" : Format.degrees(cooler.liquid)
            values: cooler.src ? cooler.src.values : []
            minimum: 20
            maximum: cooler.graphMaximum
            accent: cooler.accent
            graphName: qsTr("Liquid temperature over the last minute")
            linkText: qsTr("Open Cooler")
            rows: cooler.rows
            onLinkActivated: cooler.openCooler()
        }
    }

    Row {
        id: row
        spacing: 1

        ReadingItem {
            id: liquidItem
            config: cooler.config
            compact: cooler.compact
            vertical: cooler.vertical
            preview: cooler.preview
            host: cooler.host
            accent: cooler.accent
            label: qsTr("Liquid")
            valueText: isNaN(cooler.liquid) ? "" : Format.degrees(cooler.liquid)
            accessibleName: cooler.accessibleName
            icon: "droplet"
            openText: qsTr("Open Cooler")
            openIcon: "menu-settings"
            openAction: () => cooler.openCooler()
            removeTarget: cooler
            panel: Component {
                Loader {
                    sourceComponent: coolerPanel
                    Component.onCompleted: liquidItem.panelOpen = true
                    Component.onDestruction: liquidItem.panelOpen = false
                }
            }
        }

        ReadingItem {
            id: gpuItem
            config: cooler.config
            compact: cooler.compact
            vertical: cooler.vertical
            preview: cooler.preview
            host: cooler.host
            accent: cooler.accent
            shown: !cooler.vertical && !isNaN(cooler.gpuTemperature)
            label: qsTr("Graphics")
            valueText: Format.degrees(cooler.gpuTemperature)
            accessibleName: qsTr("Graphics %1 degrees").arg(Math.round(cooler.gpuTemperature))
            icon: "thermometer"
            openText: qsTr("Open Cooler")
            openIcon: "menu-settings"
            openAction: () => cooler.openCooler()
            removeTarget: cooler
            panel: Component {
                Loader {
                    sourceComponent: coolerPanel
                    Component.onCompleted: gpuItem.panelOpen = true
                    Component.onDestruction: gpuItem.panelOpen = false
                }
            }
        }
    }
}
