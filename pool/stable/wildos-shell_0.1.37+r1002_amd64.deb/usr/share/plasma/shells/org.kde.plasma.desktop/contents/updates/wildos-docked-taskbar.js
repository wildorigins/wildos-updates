// The taskbar is docked by default now (a 52 px bar along the bottom). A
// panel set up before that is the 76 px floating one; Plasma runs this once
// per account, which moves it to the docked height to match the new
// default. Settings > Personalisation switches back to floating.
// Only the taskbar, the panel with the apps or Start on it.
panels().forEach(function (p) {
    if (p.widgets("org.wildos.tasks").length === 0 && p.widgets("org.wildos.start").length === 0) {
        return;
    }
    if (p.location === "bottom" && p.height === 76) {
        p.height = 52;
    }
});
