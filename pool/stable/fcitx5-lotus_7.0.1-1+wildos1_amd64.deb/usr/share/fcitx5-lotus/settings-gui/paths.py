# SPDX-FileCopyrightText: 2026 Nguyen Hoang Ky <nhktmdzhg@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later
"""Installation paths configured at build time."""

LOCALE_DIR = "/usr/share/locale"
DICTIONARY_PATH = "/usr/share/fcitx5/lotus/vietnamese.cm.dict"
