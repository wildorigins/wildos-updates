# SPDX-FileCopyrightText: 2026 Nguyen Hoang Ky <nhktmdzhg@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later
"""
Auto-generated version file by CMake.
"""

__version__ = "7.0.1 (Stable)"
