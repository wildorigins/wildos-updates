/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/*************************************************************************
 *
 *  The Contents of this file are made available subject to the terms of
 *  the BSD license.
 *
 *  Copyright 2000, 2010 Oracle and/or its affiliates.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Sun Microsystems, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 *  OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 *  TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 *  USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *************************************************************************/
import com.sun.star.beans.Property;
import com.sun.star.beans.PropertyValue;

public class SwingUnoPropertyNode extends SwingUnoNode implements XUnoPropertyNode{

    private UnoPropertyNode m_oUnoPropertyNode = null;


    public SwingUnoPropertyNode(Property _aProperty, Object _oUnoObject, Object _oUnoReturnObject) {
        super(_oUnoObject);
        m_oUnoPropertyNode = new UnoPropertyNode(_aProperty, _oUnoObject, _oUnoReturnObject);
        super.setUserObject(m_oUnoPropertyNode.getLabel());
        setFoldable(m_oUnoPropertyNode.isFoldable());
    }


    public SwingUnoPropertyNode(Property _aProperty){
        super(null);
        m_oUnoPropertyNode = new UnoPropertyNode(_aProperty);
    }


    public SwingUnoPropertyNode(PropertyValue _aPropertyValue, Object _oUnoObject, Object _oUnoReturnObject) {
        super(_oUnoObject);
        m_oUnoPropertyNode = new UnoPropertyNode(_aPropertyValue, _oUnoObject, _oUnoReturnObject);
    }

    @Override
    public String getName(){
        return m_oUnoPropertyNode.getName();
    }


    public Object getUnoReturnObject(){
        return m_oUnoPropertyNode.getUnoReturnObject();
    }


    @Override
    public String getClassName(){
        String sClassName = m_oUnoPropertyNode.getClassName();
        if (sClassName.equals("")){
            sClassName = super.getClassName();
        }
        return sClassName;
    }

    @Override
    public String getAnchor(){
        return m_oUnoPropertyNode.getAnchor();
    }

    public int getPropertyNodeType(){
        return m_oUnoPropertyNode.getPropertyNodeType();
    }


    public void setPropertyNodeType(int _nPropertyType){
        m_oUnoPropertyNode.setPropertyNodeType(_nPropertyType);
    }

    public Property getProperty(){
        return m_oUnoPropertyNode.getProperty();
    }

}

/* vim:set shiftwidth=4 softtabstop=4 expandtab: */
