pragma ComponentBehavior: Bound

import QtQuick
import ".."
import "../readings"
import "../readings/Format.js" as Format

// Battery: the ring filled to the charge, "Battery 82%" and the time left
// in the faint ink ("2 h 10 min"), or "Charging" while it charges. Only on
// a PC with a battery. At 10% and below, not plugged in, the ring turns
// the warning colour the taskbar's battery uses (the bar is always dark).
// The panel has no graph: a minute of a battery says nothing.
ReadingItem {
    id: battery

    readonly property var src: loader.item
    readonly property int percent: preview ? 82 : src ? src.percent : 0
    readonly property bool pluggedIn: !preview && src !== null && src.pluggedIn
    readonly property bool charging: !preview && src !== null && src.charging
    readonly property real remaining: preview ? 2.2 * 3600000 : src ? src.remainingMsec : 0
    readonly property bool low: !pluggedIn && percent <= 10

    readonly property string status: {
        if (preview || !src) {
            return qsTr("On battery");
        }
        if (src.fullyCharged) {
            return qsTr("Fully charged");
        }
        if (src.notCharging) {
            return qsTr("Plugged in, not charging");
        }
        return charging ? qsTr("Charging") : qsTr("On battery");
    }
    readonly property string timeText: remaining > 0 && (charging || !pluggedIn) ? Format.shortDuration(remaining) : ""

    shown: preview || (src !== null && src.hasBattery)
    label: qsTr("Battery")
    valueText: Format.percent(percent)
    widestValue: Format.percent(100)
    ring: percent / 100
    glyph: "battery"
    ringColor: low ? "#f2c46b" : accent
    accessibleName: timeText.length > 0
        ? qsTr("Battery %1, %2, %3").arg(valueText).arg(status).arg(charging ? qsTr("%1 until full").arg(timeText) : qsTr("%1 left").arg(timeText))
        : qsTr("Battery %1, %2").arg(valueText).arg(status)
    openText: qsTr("Power settings")
    openIcon: "menu-settings"
    openAction: () => battery.openPowerSettings()
    content: compact || vertical ? null : detail

    function openPowerSettings(): void {
        if (!host) {
            return;
        }
        host.closePopup();
        if (typeof host.openSettings === "function") {
            host.openSettings("power");
        } else {
            host.launch("org.wildos.settings.desktop");
        }
    }

    Component {
        id: detail
        ReadingText {
            visible: text.length > 0
            color: Qt.rgba(1, 1, 1, 0.42)
            text: battery.charging ? qsTr("Charging") : battery.timeText
        }
    }

    // Loaded whatever `live` is: the model is told about changes rather
    // than asking, and the item has to know whether there is a battery to
    // show at all.
    Loader {
        id: loader
        active: !battery.preview
        source: "../readings/BatterySource.qml"
    }

    panel: Component {
        ReadingPanel {
            title: battery.label
            value: battery.valueText
            showGraph: false
            accent: battery.accent
            linkText: battery.openText
            rows: {
                const list = [{ label: qsTr("Status"), value: battery.status }];
                if (battery.timeText.length > 0) {
                    list.push({ label: battery.charging ? qsTr("Time to full") : qsTr("Time left"),
                                value: qsTr("About %1").arg(Format.duration(battery.remaining)) });
                }
                return list;
            }
            onLinkActivated: battery.openPowerSettings()
            Component.onCompleted: battery.panelOpen = true
            Component.onDestruction: battery.panelOpen = false
        }
    }
}
