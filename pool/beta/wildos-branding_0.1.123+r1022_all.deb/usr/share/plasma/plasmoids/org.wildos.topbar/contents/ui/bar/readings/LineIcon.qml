import QtQuick
import QtQuick.Shapes

// The boards' line icons for readings that WildOS.UI's set does not have
// (arrows, droplet, thermometer, weather), with the paths copied
// from the boards on the same 24px grid: 2px stroke, round caps and joins.
Item {
    id: icon

    property string name
    property color color: Qt.rgba(1, 1, 1, 0.86)
    property real size: 14
    property real strokeWidth: 2

    implicitWidth: size
    implicitHeight: size

    readonly property string cloudBase: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"
    readonly property var paths: ({
        "arrow-down": "M12 5v14M19 12l-7 7-7-7",
        // The readings, for Compact, where their names are left out.
        "cpu": "M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM9.5 9h5v6h-5zM9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3",
        "memory": "M3 6h18a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1zM7 10v4M12 10v4M17 10v4M6 18v3M10 18v3M14 18v3M18 18v3",
        "disk": "M22 12H2M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11zM6 16h.01M10 16h.01",
        "battery": "M4 7h12a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zM22 11v2",
        "gpu": "M2 4v17M2 6h18a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H2M7 17v3h7v-3M9 11.5a2 2 0 1 0 4 0a2 2 0 1 0-4 0M16 11.5h2",
        "arrow-up": "M5 12l7-7 7 7M12 19V5",
        "droplet": "M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",
        "thermometer": "M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z",
        "sun": "M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41",
        "moon": "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",
        "cloud": "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
        "cloud-sun": "M12 2v2M4.93 4.93l1.41 1.41M20 12h2M19.07 4.93l-1.41 1.41M15.947 12.65a4 4 0 0 0-5.925-4.128M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z",
        "cloud-moon": "M13 16a3 3 0 1 1 0 6H7a5 5 0 1 1 4.9-6ZM10.1 9A6 6 0 0 1 16 4a4.24 4.24 0 0 0 6 6 6 6 0 0 1-3 5.197",
        "cloud-rain": icon.cloudBase + "M16 14v6M8 14v6M12 16v6",
        "cloud-drizzle": icon.cloudBase + "M8 19v1M8 14v1M16 19v1M16 14v1M12 21v1M12 16v1",
        "cloud-snow": icon.cloudBase + "M8 15h.01M8 19h.01M12 17h.01M12 21h.01M16 15h.01M16 19h.01",
        "cloud-fog": icon.cloudBase + "M16 17H7M17 21H9",
        "cloud-lightning": "M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973M13 12l-3 5h4l-3 5"
    })

    Shape {
        width: 24
        height: 24
        preferredRendererType: Shape.CurveRenderer
        transform: Scale {
            xScale: icon.size / 24
            yScale: icon.size / 24
        }

        ShapePath {
            strokeColor: icon.color
            strokeWidth: icon.strokeWidth
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            joinStyle: ShapePath.RoundJoin
            PathSvg {
                path: icon.paths[icon.name] || ""
            }
        }
    }
}
