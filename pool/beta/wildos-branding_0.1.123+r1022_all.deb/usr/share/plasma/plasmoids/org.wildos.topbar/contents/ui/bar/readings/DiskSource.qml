import QtQuick
import org.wildos.shell as WildOS

// Disk activity (bytes read and written a second) and the system drive's
// space, from WildOS.DiskStats: ksystemstats' "all disks" figures are empty
// on an encrypted system drive, which is how Wild OS installs.
Item {
    id: source

    property bool live: false

    readonly property bool ready: stats.ready
    readonly property real readRate: stats.readRate
    readonly property real writeRate: stats.writeRate
    readonly property real freeBytes: stats.freeBytes
    readonly property real totalBytes: stats.totalBytes
    readonly property alias values: history.values

    WildOS.DiskStats {
        id: stats
        live: source.live
    }

    History {
        id: history
        live: source.live
        sample: () => source.ready ? source.readRate + source.writeRate : NaN
    }
}
