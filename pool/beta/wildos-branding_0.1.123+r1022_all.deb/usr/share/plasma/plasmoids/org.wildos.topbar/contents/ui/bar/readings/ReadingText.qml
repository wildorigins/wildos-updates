import QtQuick
import WildOS.UI as UI

// Text on the bar: 12.5px Albert Sans, white. A value (`figures`) is 550
// weight with tabular figures so it does not jitter as it changes.
UI.Label {
    id: reading

    property bool figures: false
    // The widest this value gets, as a string or a list of strings: the
    // text is never narrower than that, so the bar doesn't grow and shrink
    // as a reading goes from 9 to 10 or from KB/s to MB/s. Numbers sit
    // against the right edge, as in Task Manager's columns.
    property var widest: ""

    readonly property real widestWidth: {
        const samples = [].concat(widest);
        let most = 0;
        for (let i = 0; i < samples.length; ++i) {
            if (String(samples[i]).length > 0) {
                most = Math.max(most, metrics.advanceWidth(String(samples[i])));
            }
        }
        return Math.ceil(most);
    }

    anchors.verticalCenter: parent ? parent.verticalCenter : undefined
    width: Math.max(implicitWidth, widestWidth)
    horizontalAlignment: widestWidth > 0 ? Text.AlignRight : Text.AlignLeft
    size: 12.5
    color: "#ffffff"
    elide: Text.ElideNone
    font.weight: figures ? UI.Style.weightSemiBold : UI.Style.weightRegular
    font.features: figures ? { "tnum": 1 } : {}

    FontMetrics {
        id: metrics
        font: reading.font
    }
}
