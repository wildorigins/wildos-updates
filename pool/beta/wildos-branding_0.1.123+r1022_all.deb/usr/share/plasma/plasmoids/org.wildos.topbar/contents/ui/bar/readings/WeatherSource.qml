import QtQuick
import org.kde.plasma.plasma5support as P5Support
import org.kde.plasma.private.weather as Weather

// Today's weather for one place from Plasma's weather engine, connected only
// while the bar is live and refreshed every 30 minutes, as Plasma's Weather
// widget does.
Item {
    id: weather

    property bool live: false
    property string weatherSource: ""
    // "c" or "f" from the item's own setting; empty follows the region.
    property string unit: ""
    readonly property bool fahrenheit: unit === "f" || (unit !== "c" && Qt.locale().measurementSystem === Locale.ImperialUSSystem)
    readonly property var report: weatherSource.length > 0 ? weatherEngine.data[weatherSource] || null : null
    readonly property bool ready: report !== null && report["Temperature"] !== undefined && report["Temperature"] !== ""

    // KUnitConversion's Celsius and Fahrenheit. Plasma's default gives the
    // UK Fahrenheit, as its measurement system is imperial.
    readonly property int displayUnit: fahrenheit ? 6002 : 6001
    readonly property int reportUnit: report ? Number(report["Temperature Unit"]) || -1 : -1

    readonly property string temperature: ready ? temperatureText(report["Temperature"]) : ""
    readonly property string conditions: report ? String(report["Current Conditions"] || "") : ""
    readonly property string place: report ? String(report["Place"] || "") : ""
    readonly property string creditUrl: report ? String(report["Credit Url"] || "") : ""
    readonly property string iconName: {
        const icon = report ? String(report["Condition Icon"] || "") : "";
        if (icon.length > 0 && icon !== "weather-none-available") {
            return icon;
        }
        return todayTokens.length === 6 && todayTokens[1] !== "N/U" ? todayTokens[1] : "";
    }
    // "Day|icon|summary|high|low|chance of rain"
    readonly property var todayTokens: report ? String(report["Short Forecast Day 0"] || "").split("|") : []
    readonly property string high: todayTokens.length === 6 ? temperatureText(todayTokens[3]) : ""
    readonly property string low: todayTokens.length === 6 ? temperatureText(todayTokens[4]) : ""
    readonly property string humidity: report && report["Humidity"] !== undefined && report["Humidity"] !== ""
        ? Weather.Util.percentToDisplayString(Number(report["Humidity"])) : ""

    function temperatureText(value: var): string {
        const n = parseFloat(value);
        if (isNaN(n)) {
            return "";
        }
        // Plasma writes "14 °C"; the degrees go tight to the number, and the
        // letter stays so it is clear which scale is in use.
        return Weather.Util.temperatureToDisplayString(displayUnit, n, reportUnit, true, false).replace(/\s+°/, "°");
    }

    P5Support.DataSource {
        id: weatherEngine
        engine: "weather"
        connectedSources: weather.live && weather.weatherSource.length > 0 ? [weather.weatherSource] : []
        interval: 30 * 60 * 1000
    }
}
