.pragma library

// The layout a new top bar starts with (board 4.15): Search, the Projects
// folder, Clipboard and Capture on the left; Now playing in the middle;
// Processor, Memory, Graphics, Network speed and a clock for Tokyo on the
// right. projectsPath is ~/Projects when it exists, otherwise ~/Documents:
// the bar never makes folders in someone's home.
function defaultLayout(projectsPath) {
    return {
        left: [
            { type: "search" },
            { type: "path", path: projectsPath },
            { type: "clipboard" },
            { type: "capture" }
        ],
        middle: [
            { type: "media" }
        ],
        right: [
            { type: "cpu" },
            { type: "memory" },
            { type: "gpu" },
            { type: "network" },
            { type: "clock", zone: "Asia/Tokyo", city: "Tokyo" }
        ]
    };
}

const regions = ["left", "middle", "right"];

const types = ["search", "path", "clipboard", "capture", "media", "cpu", "memory", "gpu",
    "network", "disk", "battery", "clock", "weather", "cooler"];

// A layout read from wildosrc, made safe to draw: three arrays of objects
// with a known type. Anything unreadable gives the default layout, as the
// brief's config contract says; unknown entries in a readable layout are
// dropped so one bad entry does not cost the rest.
function normalise(layout, projectsPath) {
    if (!layout || typeof layout !== "object" || Array.isArray(layout)) {
        return defaultLayout(projectsPath);
    }
    // TopBarSettings hands over Qt's own list type, which Array.isArray
    // does not accept, so every saved layout read as unreadable and the bar
    // fell back to the default. A round trip makes plain arrays of it.
    try {
        layout = JSON.parse(JSON.stringify(layout));
    } catch (e) {
        return defaultLayout(projectsPath);
    }
    const out = {};
    let any = false;
    for (const r of regions) {
        const list = Array.isArray(layout[r]) ? layout[r] : [];
        if (Array.isArray(layout[r])) {
            any = true;
        }
        out[r] = list.filter(e => e && typeof e === "object" && types.indexOf(e.type) >= 0
            && (e.type !== "path" || (typeof e.path === "string" && e.path.length > 0)));
    }
    return any ? out : defaultLayout(projectsPath);
}

function copy(layout) {
    return JSON.parse(JSON.stringify(layout));
}

function same(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}

// Where to put an entry, taking it out of its old place first when it is
// being moved within the same region.
function moved(layout, fromRegion, fromIndex, toRegion, toIndex) {
    const next = copy(layout);
    const entry = next[fromRegion].splice(fromIndex, 1)[0];
    if (!entry) {
        return next;
    }
    let at = toIndex;
    if (fromRegion === toRegion && fromIndex < toIndex) {
        at -= 1;
    }
    at = Math.max(0, Math.min(at, next[toRegion].length));
    next[toRegion].splice(at, 0, entry);
    return next;
}

function removed(layout, region, index) {
    const next = copy(layout);
    next[region].splice(index, 1);
    return next;
}

// The entry at region/index with `changes` laid over its settings.
function configured(layout, region, index, changes) {
    const next = copy(layout);
    next[region][index] = Object.assign({}, next[region][index], changes);
    return next;
}

function inserted(layout, region, index, entries) {
    const next = copy(layout);
    const at = index < 0 ? next[region].length : Math.min(index, next[region].length);
    next[region].splice(at, 0, ...entries);
    return next;
}

function circle(cx, cy, r) {
    return "M" + (cx - r) + " " + cy
        + "A" + r + " " + r + " 0 1 0 " + (cx + r) + " " + cy
        + "A" + r + " " + r + " 0 1 0 " + (cx - r) + " " + cy + "Z";
}

function rect(x, y, w, h, rad) {
    return "M" + (x + rad) + " " + y + "H" + (x + w - rad)
        + "A" + rad + " " + rad + " 0 0 1 " + (x + w) + " " + (y + rad)
        + "V" + (y + h - rad)
        + "A" + rad + " " + rad + " 0 0 1 " + (x + w - rad) + " " + (y + h)
        + "H" + (x + rad)
        + "A" + rad + " " + rad + " 0 0 1 " + x + " " + (y + h - rad)
        + "V" + (y + rad)
        + "A" + rad + " " + rad + " 0 0 1 " + (x + rad) + " " + y + "Z";
}

// The boards' icons on the 24px grid, drawn with UI.Glyph (stroke 2,
// round caps and joins), so the bar and the Add list match them line for
// line.
const icons = {
    search: circle(11, 11, 8) + "M21 21l-4.3-4.3",
    folder: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
    file: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7ZM14 2v4a2 2 0 0 0 2 2h4",
    clipboard: rect(8, 2, 8, 4, 1) + "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
    capture: "M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" + circle(12, 13, 3),
    plus: "M5 12h14M12 5v14",
    music: "M9 18V5l12-2v13" + circle(6, 18, 3) + circle(18, 16, 3),
    cpu: rect(4, 4, 16, 16, 2) + rect(9, 9, 6, 6, 1) + "M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2",
    memory: "M6 19v-3M10 19v-3M14 19v-3M18 19v-3M8 11V9M16 11V9M12 11V9M2 15h20M2 7a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1.1a2 2 0 0 0 0 3.837V17a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-5.1a2 2 0 0 0 0-3.837Z",
    gpu: rect(2, 3, 20, 14, 2) + "M8 21h8M12 17v4",
    network: "M3 16l4 4 4-4M7 20V4M21 8l-4-4-4 4M17 4v16",
    disk: "M22 12H2M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11zM6 16h.01M10 16h.01",
    battery: rect(2, 7, 16, 10, 2) + "M22 11v2",
    clock: circle(12, 12, 10) + "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20",
    weather: "M12 2v2M4.93 4.93l1.41 1.41M20 12h2M19.07 4.93l-1.41 1.41M15.947 12.65a4 4 0 0 0-5.925-4.128M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z",
    cooler: "M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",
    previous: "M19 20L9 12l10-8zM5 19V5",
    next: "M5 4l10 8-10 8zM19 5v14",
    pause: rect(14, 4, 4, 16, 1) + rect(6, 4, 4, 16, 1),
    play: "M6 3l14 9-14 9z",
    arrowDown: "M12 5v14M19 12l-7 7-7-7",
    arrowUp: "M5 12l7-7 7 7M12 19V5",
    back: "M15 18l-6-6 6-6",
    home: "M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
};
