pragma ComponentBehavior: Bound

import QtQuick
import ".."

// What every live reading on the bar shares (TopBar.dc, the right region):
// a ring or an icon, the muted name ("Processor"), then the value in 550
// weight with tabular figures. Compact and upright bars drop the name; the
// upright bar keeps only the ring or icon. A click opens the reading's
// panel under it, a right click its menu.
Item {
    id: item

    required property var config
    property bool compact: false
    property bool vertical: false
    property bool live: false
    property bool preview: false
    property var host: null
    property color accent: "#8fb4ff"
    property bool overclock: false

    property bool shown: true
    property string accessibleName: valueText.length > 0 ? qsTr("%1 %2").arg(label).arg(valueText) : label

    property string label
    property string valueText
    // The widest valueText gets (see ReadingText.widest), so the item keeps
    // its width as the value changes.
    property var widestValue: ""
    // 0 to 1 draws the ring; below zero draws `icon` instead.
    property real ring: -1
    property color ringColor: accent
    property string icon
    property real iconSize: 13
    // What the reading is, drawn after the ring in Compact, where the name
    // is left out: "cpu", "memory", "disk", "battery" or "gpu".
    property string glyph
    property color iconColor: Qt.rgba(1, 1, 1, 0.7)

    // Shown under the item on a click: an inline Component, so it binds to
    // this item's live values for as long as it is open.
    property Component panel: null
    property bool panelOpen: false
    // Where "Open Task Manager" lands, and the menu's first entry.
    // The Task Manager page to open: "performance/<resource>" picks the
    // matching resource on its Performance page.
    property string taskManagerPage: "performance"
    property string openText: qsTr("Open Task Manager")
    property string openIcon: "menu-task-manager"
    property var openAction: () => item.openTaskManager()
    // What "Remove from the top bar" removes: the item the bar loaded
    // (Cooler's two halves both remove the whole Cooler).
    property Item removeTarget: item

    // Drawn in the button after the value, for readings that are more than
    // a name and a number (Network's arrows, Cooler's two temperatures).
    property Component content: null
    // { text, icon, run } entries shown first in the right-click menu.
    property var menuEntries: []

    readonly property alias button: button

    implicitWidth: button.implicitWidth
    implicitHeight: button.implicitHeight
    visible: shown

    Accessible.role: Accessible.Button
    Accessible.name: accessibleName

    function activate(): void {
        if (preview || !host) {
            return;
        }
        if (panelOpen) {
            host.closePopup();
            return;
        }
        if (panel) {
            host.showPopup(button, panel, {});
        } else {
            openAction();
        }
    }

    function openTaskManager(): void {
        if (!host) {
            return;
        }
        host.closePopup();
        host.openTaskManager(taskManagerPage);
    }

    function openMenu(): void {
        if (preview || !host) {
            return;
        }
        const entries = menuEntries.slice();
        if (entries.length > 0) {
            entries.push({ separator: true });
        }
        if (openText.length > 0) {
            entries.push({ text: openText, icon: openIcon, run: () => item.openAction() });
            entries.push({ separator: true });
        }
        if (typeof host.removeItem === "function") {
            entries.push({ text: qsTr("Remove from the top bar"), icon: "unpin", run: () => item.host.removeItem(item.removeTarget) });
        }
        entries.push({ text: qsTr("Edit the top bar"), icon: "pencil", run: () => item.host.startEdit() });
        host.contextMenu(button, entries);
    }

    BarButton {
        id: button
        compact: item.compact
        vertical: item.vertical
        preview: item.preview
        open: item.panelOpen
        tip: item.vertical ? item.accessibleName : ""
        onClicked: item.activate()
        onRightClicked: item.openMenu()

        RingGauge {
            anchors.verticalCenter: parent.verticalCenter
            visible: item.ring >= 0
            value: Math.max(0, item.ring)
            color: item.ringColor
        }
        LineIcon {
            anchors.verticalCenter: parent.verticalCenter
            visible: item.ring < 0 && item.icon.length > 0
            name: item.icon
            size: item.iconSize
            color: item.iconColor
        }
        LineIcon {
            anchors.verticalCenter: parent.verticalCenter
            visible: item.compact && !item.vertical && item.ring >= 0 && item.glyph.length > 0
            name: item.glyph
            size: 13
            color: button.inkMuted
        }
        ReadingText {
            visible: !item.compact && !item.vertical && item.label.length > 0
            color: button.inkMuted
            text: item.label
        }
        ReadingText {
            visible: !item.vertical && item.valueText.length > 0
            figures: true
            widest: item.widestValue
            text: item.valueText
        }
        Loader {
            anchors.verticalCenter: parent.verticalCenter
            active: item.content !== null
            visible: active
            sourceComponent: item.content
        }
    }
}
