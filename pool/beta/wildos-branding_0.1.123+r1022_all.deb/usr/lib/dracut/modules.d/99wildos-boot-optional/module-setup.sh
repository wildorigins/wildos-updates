#!/bin/bash
# Debian's dracut in host-only mode makes start-up wait without end for the
# devices behind /boot and the EFI partition (its 99base), though nothing
# before the switch to the installed system needs them. When one of them
# gets a new ID (a Windows partition app resizing the disk, a firmware
# update recreating the EFI partition) the PC stopped at the logo for good.
# The waits for those two are taken out again here, after 99base; the
# system drive and its encryption are still waited for. Once running, the
# EFI partition is mounted from fstab with nofail.

check() {
    [[ $hostonly ]] || return 255
    return 0
}

depends() {
    echo base
}

install() {
    local mp source root ids id hook dev name unit
    root=$(findmnt -no SOURCE /)
    for mp in /boot /boot/efi /efi; do
        mountpoint -q "$dracutsysrootdir$mp" || continue
        source=$(findmnt -no SOURCE "$mp")
        [[ -n $source && $source != "$root" ]] || continue
        ids="$(findmnt -no UUID "$mp") $(findmnt -no PARTUUID "$mp")"
        for hook in "$initdir"/lib/dracut/hooks/initqueue/finished/devexists-*.sh; do
            [[ -e $hook ]] || continue
            dev=$(sed -n 's/^\[ -e "\(.*\)" \]$/\1/p' "$hook" | head -n 1)
            for id in $ids; do
                [[ -n $id && $dev == *"$id"* ]] || continue
                name=$(basename "$hook" .sh)
                rm -f -- "$hook" "$initdir/lib/dracut/hooks/emergency/80-${name#devexists-}.sh"
                unit=$(systemd-escape -p --suffix=device "$dev")
                rm -f -- "$initdir/etc/systemd/system/initrd.target.wants/$unit"
                rm -rf -- "$initdir/etc/systemd/system/$unit.d"
                break
            done
        done
    done
}
