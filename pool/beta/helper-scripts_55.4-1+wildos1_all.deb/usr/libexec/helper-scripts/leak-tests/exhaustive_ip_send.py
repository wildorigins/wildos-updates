#!/usr/bin/python3 -Bsu

## Copyright (C) 2012 - 2025 ENCRYPTED SUPPORT LLC <adrelanos@whonix.org>
## See the file COPYING for copying conditions.

from scapy.all import *

#define the target gateway & data payload
target = "scanme.nmap.org"
#target = "45.33.32.156"

data = "testing"

#define packet
ip = IP()

#define packet parameters
ip.dst = target

#loop through all IP packet types
for ip_type in range(0,255):
        ip.proto = ip_type
        send(ip/data)
