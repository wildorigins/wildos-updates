#!/usr/bin/python3 -Bsu

## Copyright (C) 2012 - 2025 ENCRYPTED SUPPORT LLC <adrelanos@whonix.org>
## See the file COPYING for copying conditions.

from scapy.all import *

#define the target gateway & data payload
target = "scanme.nmap.org"
#target = "45.33.32.156"

data = "testing"

#define packets
ip = IP()
udp = UDP()

#define packet parameters
ip.dst = target

#loop through all TCP ports
for udp_port in range(0,65535):
        udp.dport = udp_port
        send(ip/udp/data)
