#!/bin/bash

## Copyright (C) 2025 - 2025 ENCRYPTED SUPPORT LLC <adrelanos@whonix.org>
## See the file COPYING for copying conditions.

sudo_useable_test() {
   use_sudo='no'

#    local id_user
#    if ! id_user="$(id --user)" ; then
#       echo "$0: WARNING: Cannot run 'id --user'. Cannot use sudo." >&2
#       return 0
#    fi
#
#    if [ "$id_user" = "0" ] ; then
#       true "$0: INFO: Already using account root / id 0. No need to use sudo."
#       return 0
#    fi

   if ! sudo_exe="$(command -v sudo)"; then
      true "$0: INFO: sudo executable cannot be found. Cannot use sudo."
      return 0
   fi

   ## Debugging.
   ## sets: boot_session
   source "${HELPER_SCRIPTS_PATH:-}"/usr/libexec/helper-scripts/boot-session-detection.bsh

   if ! test -x "$sudo_exe"; then
      true "$0: INFO: sudo is not executable. Cannot use sudo."
      return 0
   fi

   use_sudo='yes'
}

sudo_error_exit_if_unavailable() {
   local msg_type err_text

   msg_type="${1:-cli}"
   err_text="ERROR: sudo unavailable. Boot into sysmaint session?"

   if [ "${use_sudo}" = "no" ]; then
      if [ "${msg_type}" = 'graphical' ]; then
         /usr/libexec/msgcollector/generic_gui_message \
            error "sudo unavailable" "${err_text}" "" ok || true
      else
         printf '%s\n' "${err_text}"
      fi
      exit 1
   fi
}

sudo_useable_test
